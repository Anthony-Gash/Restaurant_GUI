package gui.tablesTab;

import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.util.Callback;
import tables.Table;

public class TableCellFactory implements Callback<ListView<Table>, ListCell<Table>> {

    @Override
    public ListCell<Table> call(ListView<Table> listView) {
        return new CustomTableCell();
    }

    // Custom ListCell subclass
    private static class CustomTableCell extends ListCell<Table> {
        private final Button cycleButton = new Button("Change Status");

        public CustomTableCell() {
            // Handle button click event to cycle through statuses
            cycleButton.setOnAction(event -> {
                Table table = getItem();
                if (table != null) {
                    table.cycleStatus(); // Cycle the status of the table
                    updateItem(table, isEmpty());
                }
            });
        }

        @Override
        protected void updateItem(Table item, boolean empty) {
            super.updateItem(item, empty);

            if (empty || item == null) {
                setText(null);
                setGraphic(null);
            } else {
                setText("\t\t" + item.getTableNumber() + "\t\t" + item.getStatus());
                setGraphic(cycleButton);
            }
        }
    }
}
