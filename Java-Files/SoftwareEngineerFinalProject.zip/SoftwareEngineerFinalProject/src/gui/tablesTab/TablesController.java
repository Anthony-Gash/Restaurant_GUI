package gui.tablesTab;

import tables.Tables;
import tables.Table;
import tables.tableStatus;

import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import gui.ordersTab.AddOrderTabController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;

/**
 * This class defines a Controller for the Tables tab, which contains the ability
 * to change the status of a table and to view the list of tables and their
 * statuses.
 * @author Nathaniel Gordon
 * */

public class TablesController {

	//************************
	// FXML-injectable fields
	//************************
	
	@FXML
	private Label tableListLabel; //Label that displays the list of tables below

	@FXML
	private Button cycleStatusButton; /*Button that cycles through the 
    statuses for the tables. Order goes from: 
    AVAILABLE ---> OCCUPIED ---> NEEDS_CLEANING*/

	@FXML
	private Button clearButton;
	//Button for resetting all statuses

	@FXML
	private HBox statusBox; // Assuming this is the HBox container that holds the button, label, and circles

	@FXML
	private ListView<Table> tableListView; //ListView that contains the list of all tables

	//location and resources will be injected by the FXML loader object
	@FXML
	private URL location;

	@FXML
	private ResourceBundle resources;

	//*****************
	// Other fields
	//*****************
	
	private static Tables tables; //Load in the Tables objects from the Tables.java file
	
	/* ListView that displays all tables,
	including table number and status of each table*/
	private ObservableList<Table> tableListViewData = FXCollections.observableArrayList();
	
	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public TablesController() {
	}

	/**
	 * This is a private method with a void return
	 * type, and is needed by the FXML loader object.
	 */
	@FXML
	private void initialize() {	

		// Initialize the cell factory for the tableListView
		tableListView.setCellFactory(new StatusIndicatorCellFactory());
		tableListView.setItems(tableListViewData);

		// Initialize the Tables class
		tables = new Tables();

		// Get the list of tables
		List<Table> tablesList = tables.getTables();

		// Populate the ListView with the list of tables
		tableListViewData.addAll(tablesList);
		tableListView.setItems(tableListViewData);

		// Center the ListView within its parent container
		tableListView.getParent().setStyle("-fx-alignment: center;");

	}

	// Method to handle button click event
	@FXML
	private void handleCycleStatusButton() {
		// Handle button click event
		// Call the method to cycle table status
		Table selectedTable = tableListView.getSelectionModel().getSelectedItem();
		if (selectedTable != null) {
			selectedTable.cycleStatus();
			tableListView.refresh(); // Refresh the TableView to reflect changes
		}
	}

	@FXML
	private void handleClearButtonAction() {
		// Create a confirmation dialog
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setTitle("Confirm Reset");
		alert.setHeaderText("Reset All Table Statuses");
		alert.setContentText("Are you sure you want to reset all table statuses to AVAILABLE?");

		// Show the dialog and wait for the user's response
		Optional<ButtonType> response = alert.showAndWait();

		// If the user confirms, reset all table statuses to Available
		if (response.isPresent() && response.get() == ButtonType.OK) {
			for (Table table : tables.getTables()) {
				table.setStatus(tableStatus.AVAILABLE);
			}
			// Refresh the ListView to reflect the changes
			tableListView.refresh();
		}
	}

	/**
	 * Gets a new Tables object that has the same state
	 * as the private Tables object handled by this Controller class.
	 * 
	 * This lets other code access the current state of the private Tables
	 * object here but the deep copying keeps that other code from being
	 * able to manipulate any data to cause harm to this file's data. 
	 * 
	 * @return A new Tables object that is a deep copy of the private one in this class.
	 */
	public static Tables getTables() {
		return new Tables(tables);
	}
}
