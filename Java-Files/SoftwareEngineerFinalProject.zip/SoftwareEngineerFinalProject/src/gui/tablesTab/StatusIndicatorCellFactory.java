package gui.tablesTab;

import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.util.Callback;
import tables.Tables;
import tables.Table;
import tables.tableStatus;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class StatusIndicatorCellFactory implements Callback<ListView<Table>, ListCell<Table>> {
	@Override
	public ListCell<Table> call(ListView<Table> listView) {
		return new ListCell<Table>() {
			@Override
			protected void updateItem(Table table, boolean empty) {
				super.updateItem(table, empty);

				if (empty || table == null) {
					setText(null);
					setGraphic(null);
				} else {
					HBox statusBox = new HBox(); // Container for status elements
					Button cycleStatusButton = new Button("Change Status"); // Button to cycle table status
					Label tableNumberLabel = new Label(Integer.toString(table.getTableNumber())); // Table number label
					Label statusLabel = new Label(table.getStatus().toString()); // Status label
					Circle statusCircle = new Circle(6); // Colored circle

					// Set circle color based on status
					statusCircle.setFill(getColorForStatus(table.getStatus())); 

					// Set spacing between elements in the statusBox
					statusBox.setSpacing(50);

					// Add event handler for the cycle status button
					cycleStatusButton.setOnAction(event -> {
						table.cycleStatus();
						statusLabel.setText(table.getStatus().toString()); // Update status label
						statusCircle.setFill(getColorForStatus(table.getStatus())); // Update circle color
					});

					// Add elements to the statusBox
					statusBox.getChildren().addAll(cycleStatusButton, tableNumberLabel, statusLabel, statusCircle); 

					// Set the container as the cell graphic
					setGraphic(statusBox);
				}
			}

			//This sets the color of the circle, depending on the status
			private Color getColorForStatus(tableStatus status) {
				switch (status) {
				case AVAILABLE:
					return Color.GREEN;
				case OCCUPIED:
					return Color.RED;
				case NEEDS_CLEANING:
					return Color.YELLOW;
				default:
					return Color.BLACK; // Default color
				}
			}

		};
	}
}
