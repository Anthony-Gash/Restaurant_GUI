package gui;

//import package.fileName;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
//import javafx.scene.control.ComboBox;
//import javafx.scene.control.TextField;

/**
 * The FXML Controller class gets connected to the application GUI
 * and is used to initialize the UI elements.
 * 
 * Event handlers can also be implemented here.
 * 
 * @author Luke Hoffman (gmaj9)
 * 
 */

public class RestaurantGUIController {
	
    //@FXML
	//private TextField addOrderCustNameTxtField;
	
	//@FXML
	//private ComboBox<Integer> addOrderTableNumComboBox;
	
	//location and resources will be injected by the FXML loader object
	@FXML
	private URL location;
	
	@FXML
	private ResourceBundle resources;
	
	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public RestaurantGUIController() {
	}
	
	/**
	 * This is a private method with a void return
	 * type, and is needed by the FXML loader object.
	 */
	@FXML
	private void initialize() {	
	}
	
}
