package gui.testing;
import employees.Schedule;

import java.util.List;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.*;

public class AlertBox 
{
	
	public static void displaySchedule(Schedule s)
	{
		Stage window = new Stage();
		
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle("Employees on Schedule");
		window.setMinWidth(800);
		Button submitButton = new Button("Exit");
		submitButton.setOnAction(e->window.close());
		
		VBox layout = new VBox(10);
		for (int i = 0;i < s.getEmployee().size(); i++)
		{
			layout.getChildren().addAll(new Label(s.getEmployee().get(i).toString()));
		}
		layout.getChildren().add(submitButton);
		layout.setAlignment(Pos.CENTER);
		
		
		Scene scene = new Scene(layout);
		window.setScene(scene);
		window.showAndWait();
	}
	
	
}







