package gui.testing;
import employees.Employee;
import employees.Schedule;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javafx.application.*;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.*;


public class restaurantGUI extends Application
{
	Button button;
	Stage window = new Stage();
	Scene scene1, scene2, scene3, scene4, scene6, scene7;
	
	public static void main(String[] args)
	{
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception
	{
	
		//START UP MENU
		HBox topMenu = new HBox();
		HBox textMenu = new HBox();
		Button buttonA = new Button("TABLES");
		Button buttonB = new Button("RESERVATION");
		Button buttonC = new Button("ORDERS");
		Button buttonD = new Button("ADD ORDER");
		Button buttonE = new Button("VIEW SCHEDULE");
		Button buttonF = new Button("MANAGE MENUS");
		buttonB.setOnAction(e->window.setScene(scene1));
		buttonA.setOnAction(e->window.setScene(scene2));
		buttonC.setOnAction(e->window.setScene(scene3));
		buttonD.setOnAction(e->window.setScene(scene4));
		buttonE.setOnAction(e->window.setScene(scene6));
		buttonF.setOnAction(e->window.setScene(scene7));
		topMenu.getChildren().addAll(buttonA, buttonB, buttonC, buttonD, buttonE, buttonF);
		topMenu.setAlignment(Pos.CENTER);
		topMenu.setSpacing(15);
		Text text = new Text("Select an option");
		textMenu.getChildren().addAll(text);
		textMenu.setAlignment(Pos.CENTER);
		//Image image = new Image("utensils.jpeg");
		//ImageView imgv = new ImageView(image);
		//HBox bottomImage = new HBox();
		//bottomImage.getChildren().addAll(imgv);
		//bottomImage.setAlignment(Pos.CENTER);
		
		BorderPane borderPane = new BorderPane();
		borderPane.setTop(topMenu);
		borderPane.setCenter(textMenu);
		//borderPane.setBottom(bottomImage);
		Scene scene5 = new Scene(borderPane, 700, 700);
		
		
		//Creating all the back buttons
		Button backButton1 = new Button("Back");
		backButton1.setOnAction(e->window.setScene(scene5));
		Button backButton2 = new Button("Back");
		backButton2.setOnAction(e->window.setScene(scene5));
		Button backButton3 = new Button("Back");
		backButton3.setOnAction(e->window.setScene(scene5));
		Button backButton4 = new Button("Back");
		backButton4.setOnAction(e->window.setScene(scene5));
		Button backButton5 = new Button("Back");
		backButton5.setOnAction(e->window.setScene(scene5));
		Button backButton6 = new Button("Back");
		backButton6.setOnAction(e->window.setScene(scene5));
		
		//Creating all the employees
		Employee emp1 = new Employee(123, "Bill", "Nye", null);
		Employee emp2 = new Employee(124, "Joe", "Smith", null);
		Employee emp3 = new Employee(125, "Nate", "Gordon", null);
		Employee emp4 = new Employee(126, "Luke", "Hoffman", null);
		Employee emp5 = new Employee(127, "Anthony", "Gash", null);
		Employee emp6 = new Employee(128, "Jake", "Daniels", null);
		Employee emp7 = new Employee(129, "Mike", "Tyson", null);
		Employee emp8 = new Employee(130, "Brandon", "Katz", null);
		Employee emp9 = new Employee(131, "David", "Hart", null);
		Employee emp10 = new Employee(132, "John", "Wick", null);
		
		List<Employee> empList = new ArrayList<Employee> ();
		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		empList.add(emp4);
		empList.add(emp5);
		empList.add(emp6);
		empList.add(emp7);
		empList.add(emp8);
		empList.add(emp9);
		empList.add(emp10);
		
		List<Employee> empShift1 = new ArrayList<Employee> ();
		empShift1.add(emp1);
		empShift1.add(emp2);
		empShift1.add(emp3);
		empShift1.add(emp4);
		empShift1.add(emp5);
		List<Employee> empShift2 = new ArrayList<Employee> ();
		empShift2.add(emp6);
		empShift2.add(emp7);
		empShift2.add(emp8);
		empShift2.add(emp9);
		empShift2.add(emp10);
		
		Schedule sch1 =  new Schedule(1,1,2002, empShift1);
		Schedule sch2 =  new Schedule(2,3,2010, empShift2);
		
		List<Schedule> schedules = new ArrayList<Schedule> ();
		schedules.add(sch1);
		schedules.add(sch2);
		
		//RESERVATION DATA
		Label label1 =  new Label("RESERVATION DATA");
		
		
		VBox layout1 = new VBox(5);
		layout1.getChildren().addAll(backButton1, label1);
		scene1 =  new Scene (layout1, 900, 900);
		
		
		//TABLE DATA
		Label label2 =  new Label("TABLES");
		

		VBox layout2 = new VBox(7);
		layout2.getChildren().addAll(backButton2, label2);
		scene2 = new Scene(layout2, 900, 900);
		
		
		//ORDER DATA
		Label label3 =  new Label("ORDERS");
		
		VBox layout3 = new VBox(7);
		layout3.getChildren().addAll(backButton3, label3);
		scene3 = new Scene(layout3, 900, 900);
		
		
		//ADD ORDER
		Label label4 =  new Label("ADD ORDER");
		
		
		VBox layout4 = new VBox(5);
		layout4.getChildren().addAll(backButton4, label4);
		scene4 =  new Scene (layout4, 900, 900);
		
		
		//SCHEDULE
		Label label7 =  new Label("SCHEDULE");
		Label lblDay = new Label("Enter Schedule Day");
		TextField txtDay = new TextField();
		Label lblMonth = new Label("Enter Schedule Month");
		TextField txtMonth = new TextField();
		Label lblYear = new Label("Enter Schedule Year");
		TextField txtYear = new TextField();
		
		Button submitButton = new Button("Submit");
		submitButton.setOnAction(e->
		{
			int day = Integer.parseInt(txtDay.getText());
			int month = Integer.parseInt(txtMonth.getText());
			int year = Integer.parseInt(txtYear.getText());
			
			txtDay.clear();
			txtMonth.clear();
			txtYear.clear();
			
			for (int i =0; i < schedules.size(); i++)
			{
				if((schedules.get(i).getDay() == day) && (schedules.get(i).getMonth() == month) && (schedules.get(i).getYear() == year))
				{
					AlertBox.displaySchedule(schedules.get(i));
				}
				
			}
			
			
		});
		
		VBox layout5 = new VBox(7);
		layout5.getChildren().addAll(backButton5, label7, lblDay, txtDay, lblMonth, txtMonth, lblYear, txtYear, submitButton);
		scene6 = new Scene(layout5, 900, 900);
		
		
		//MANAGE MENUS
		Label label6 =  new Label("MANAGE MENU");
		
		
		VBox layout6 = new VBox(5);
		layout6.getChildren().addAll(backButton6, label6);
		scene7 =  new Scene (layout6, 900, 900);
		
		
		
		window.setScene(scene5);
		window.show();
	}
	
	
}







