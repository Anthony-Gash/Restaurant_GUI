package gui;
//import java.sql.SQLException;

//sample package import statement to use files from other packages
//import packageName.subPackageName.javaFileName;
import data.ConnectDB;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
//import javafx.scene.Parent;
//import javafx.scene.Scene;
import javafx.stage.Stage;

/***
 * This file is for getting the FXML
 * GUI to start up.
 * 
 * @author Luke Hoffman (gmaj9)
 * 
 */

public class RestaurantGUILauncher extends Application {

	/**
	 * The main method.
	 * 
	 * @param args - String array of any arguments passed to the application.
	 * @throws ClassNotFoundException 
	 */
	public static void main(String args[]) {
		launch(args);
	}


	@Override
	public void start(Stage primaryStage) throws Exception {
		//************************
		// Database setup
		//************************
		
		// Connect to the database.
		//////////ConnectDB.connect();

		// Initialize the database (create tables if they don't exist).
		//////////ConnectDB.initializeDB();

		//************************
		// GUI setup
		//************************
		
		// Load the GUI from the FXML.
		Parent root = FXMLLoader.load(getClass().getResource("RestaurantGUI_v0.4.fxml"));

		Scene scene = new Scene(root);

		primaryStage.setScene(scene);
		primaryStage.setTitle("Restaurant Management System");

		// Don't let the window be resized (it doesn't resize nicely yet).
		primaryStage.setResizable(false);

		primaryStage.show(); // Show the main GUI.
	}

	@Override
	public void stop() {
		// Close database connection before application quits.
		ConnectDB.disconnect();
	}
}