package gui.reservationsTab;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import reservations.Reservations;
import reservations.ReservationsManager;
import java.time.format.DateTimeFormatter;


/*
 * This is the controller class for the reservations tab. The
 * Reservations tab contains two subtabs, Create Reservation
 * and View Reservations.
 * @author Nathaniel Gordon
 */

public class createReservationsController {
	
	// Declare an instance of ReservationsManager
	private ReservationsManager reservationsManager;
	
	@FXML
	private Label lastNameLabel; /*Label that says "Last Name", prompting the user to enter
	a last name for the reservation.*/
	
	@FXML
	private TextField lastNameTextField; /*TextField that allows the user to enter a last
	name for the reservation.*/
	
	@FXML
	private Label dateLabel; /*Label that says "Date", prompting the user
	to select a date for the reservation.*/
	
	@FXML
	private DatePicker datePicker; /*DatePicker that allows the user to select
	a date for the reservation.*/
	
	@FXML
	private Label hourLabel; /*Label that says "Hour", prompting the user to choose
	the hour for the reservation.*/
	
	@FXML
	private ComboBox<Integer> hourComboBox; /*ComboBox that allows the user to select an
	hour for the reservation.*/
	
	@FXML
	private Label minuteLabel; /*Label that says "Minute", prompting the user to choose
	the minute for the reservation.*/
	
	@FXML
	private ChoiceBox<String> minuteChoiceBox; /*ChoiceBox that the user can select from either 0,
	15, 30, or 45.*/
	
	@FXML
	private Label amPmLabel; /*Label that says "AM/PM".*/
	
	@FXML
	private ChoiceBox<String> amPmChoiceBox; /*ChoiceBox for AM/PM.*/
	
	@FXML
	private Button confirmButton; /*Button to confirm reservation*/
	
	@FXML
	private Label reservationConfirmedLabel; /*Label that lets the user know the
	details of the reservation and that it has been confirmed.*/

	//location and resources will be injected by the FXML loader object
	@FXML
	private URL location;

	@FXML
	private ResourceBundle resources;
	
	/*
	 * Public no-args constructor needed
	 * by the FXML loader object.
	 */
	public createReservationsController() {
	}
	
	public void initialize() {
		
	    // Initialize reservationsManager instance
		reservationsManager = ReservationsManager.getInstance();

	    // Set up dummy data for reservations
	    setUpDummyData();

	    // Initialize the other components (e.g., ComboBoxes and ChoiceBoxes)
	    setUpComponents();
		
	    // Populate hour ComboBox with values from 1 to 12
	    ObservableList<Integer> hours = FXCollections.observableArrayList();
	    for (int i = 1; i <= 12; i++) {
	        hours.add(i);
	    }
	    hourComboBox.setItems(hours);

	    // Populate minute ChoiceBox with values 0, 15, 30, 45
	    ObservableList<String> minutes = FXCollections.observableArrayList();
	    for (int i : new int[]{0, 15, 30, 45}) {
	        minutes.add(String.format("%02d", i)); // Format integers as strings with leading zeros
	    }
	    minuteChoiceBox.setItems(minutes);

	    // Populate amPm ChoiceBox with values AM and PM
	    ObservableList<String> amPmOptions = FXCollections.observableArrayList("AM", "PM");
	    amPmChoiceBox.setItems(amPmOptions);
	}
	
	private void setUpDummyData() {
	    // Get the instance of ReservationsManager
	    ReservationsManager reservationsManager = ReservationsManager.getInstance();

	    // Add some dummy data for reservations on different dates using ReservationsManager
	    reservationsManager.addReservation(new Reservations("Smith", LocalDate.of(2024, 5, 15), 12, "30", "PM"));
	    reservationsManager.addReservation(new Reservations("Johnson", LocalDate.of(2024, 5, 15), 6, "15", "PM"));
	    reservationsManager.addReservation(new Reservations("Brown", LocalDate.of(2024, 5, 15), 7, "45", "AM"));
	    reservationsManager.addReservation(new Reservations("Miller", LocalDate.of(2024, 5, 15), 1, "00", "PM"));
	    reservationsManager.addReservation(new Reservations("Garcia", LocalDate.of(2024, 5, 15), 2, "15", "PM"));
	    reservationsManager.addReservation(new Reservations("Martinez", LocalDate.of(2024, 5, 16), 3, "30", "PM"));
	    reservationsManager.addReservation(new Reservations("Davis", LocalDate.of(2024, 5, 16), 4, "45", "PM"));
	    reservationsManager.addReservation(new Reservations("Rodriguez", LocalDate.of(2024, 5, 16), 10, "00", "AM"));
	    reservationsManager.addReservation(new Reservations("Clark", LocalDate.of(2024, 5, 16), 11, "15", "AM"));
	    reservationsManager.addReservation(new Reservations("Walker", LocalDate.of(2024, 5, 16), 12, "30", "PM"));
	    reservationsManager.addReservation(new Reservations("White", LocalDate.of(2024, 5, 17), 5, "45", "PM"));
	    reservationsManager.addReservation(new Reservations("Harris", LocalDate.of(2024, 5, 17), 6, "00", "PM"));
	    reservationsManager.addReservation(new Reservations("Hall", LocalDate.of(2024, 5, 17), 8, "30", "AM"));
	    reservationsManager.addReservation(new Reservations("Moore", LocalDate.of(2024, 5, 17), 9, "15", "AM"));
	    reservationsManager.addReservation(new Reservations("Taylor", LocalDate.of(2024, 5, 17), 3, "00", "PM"));


	}

	private void setUpComponents() {
	    // Set up ComboBoxes and ChoiceBoxes with data
	    ObservableList<Integer> hours = FXCollections.observableArrayList();
	    for (int i = 1; i <= 12; i++) {
	        hours.add(i);
	    }
	    hourComboBox.setItems(hours);

	    ObservableList<String> minutes = FXCollections.observableArrayList("00", "15", "30", "45");
	    minuteChoiceBox.setItems(minutes);

	    ObservableList<String> amPmOptions = FXCollections.observableArrayList("AM", "PM");
	    amPmChoiceBox.setItems(amPmOptions);
	}
	
	@FXML
	private void confirmReservationButtonClicked(ActionEvent event) {
	    // Gather input data
	    String lastName = lastNameTextField.getText();
	    LocalDate date = datePicker.getValue();
	    Integer hour = hourComboBox.getValue();
	    String minute = minuteChoiceBox.getValue();
	    String amPm = amPmChoiceBox.getValue();

	    // Check if any required field is empty
	    if (lastName.isEmpty() || date == null || hour == null || minute == null || amPm == null) {
	        // Display an error message informing the user to fill in all required fields
	        Alert alert = new Alert(Alert.AlertType.ERROR);
	        alert.setTitle("Error");
	        alert.setHeaderText(null);
	        alert.setContentText("Please fill in all required fields.");
	        alert.showAndWait();
	        return; // Exit the method without proceeding further
	    }

	    // Proceed with creating the reservation
	    // Create a new reservation
	    Reservations reservation = new Reservations(lastName, date, hour, minute, amPm);

	    // Add the reservation to the reservations manager
	    reservationsManager.addReservation(reservation);

	    // Format the date
	    LocalDate reservationDate = reservation.getDate();
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy");
	    String formattedDate = reservationDate.format(formatter);

	    // Update the label to display the confirmation message with the formatted date
	    String confirmationMessage = String.format("Reservation ID #%d for %s has been scheduled for %s at %02d:%s %s.",
	            reservation.getId(), reservation.getName(), formattedDate, reservation.getHour(), reservation.getMinute(), reservation.getAmPm());
	    reservationConfirmedLabel.setText(confirmationMessage);
	}
	
	private void printReservationsList() {
	    // Fetch all reservations from ReservationsManager
	    List<Reservations> reservations = reservationsManager.getAllReservations();

	    // Print the reservations list
	    System.out.println("Reservations in the Reservations Manager:\n");
	    if (reservations.isEmpty()) {
	        System.out.println("No reservations in the list.");
	    } else {
	        for (Reservations reservation : reservations) {
	            System.out.println(reservation);
	        }
	    }
	}





}
