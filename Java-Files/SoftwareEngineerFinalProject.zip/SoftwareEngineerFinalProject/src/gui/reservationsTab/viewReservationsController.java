package gui.reservationsTab;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import reservations.Reservations;
import reservations.ReservationsManager;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class viewReservationsController {
	
	
	private ReservationsManager reservationsManager;

    @FXML
    private DatePicker datePicker;

    @FXML
    private Button selectDateButton;

    @FXML
    private ListView<String> reservationsListView;

    // Initialize the ListView with an ObservableList
    private ObservableList<String> reservationsList = FXCollections.observableArrayList();

    // This method is called when the view is initialized
    @FXML
    public void initialize() {
    	reservationsManager = ReservationsManager.getInstance();

        // Set the initial items of the ListView
        reservationsListView.setItems(reservationsList);

        // Initialize the DatePicker with the current date
        datePicker.setValue(LocalDate.now());
    }

 // Event handler for the button to select a date
    @FXML
    private void handleSelectDateButton() {
        // Get the selected date from the DatePicker
        LocalDate selectedDate = datePicker.getValue();

        // Fetch the reservations for the selected date using the ReservationManager
        List<Reservations> reservationsForDate = reservationsManager.getReservationsForDate(selectedDate);

        // Convert the list of reservations to a list of strings
        List<String> reservationStrings = new ArrayList<>();
        for (Reservations reservation : reservationsForDate) {
            reservationStrings.add(reservation.toString());
        }

        // Update the ListView with the reservations for the selected date
        reservationsListView.getItems().setAll(reservationStrings);
        
    }

}
