package gui.ordersTab;

import data.ConnectDB;
import orders.OrderState;
import tables.Table;
import tables.Tables;
import tables.tableStatus;
import gui.tablesTab.TablesController;

import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import menu.CategoryTree;
import menu.menuItems;
import menu.menus;
import menu.menus_launcher;

/**
 * This class defines a Controller for the Add Orders tab, which is a
 * subtab of the Orders tab.
 * 
 * Event handlers are implemented here for Add Orders GUI elements.
 * 
 * @author Luke Hoffman (gmaj9)
 * Plus some code adapted/copied from code by:
 * @author Anthony Gash (agash2)
 */
public class AddOrderTabController {

	//**************************
	// Fields - FXML-injectable
	//**************************

	// Whatever GUI elements are needed for the event handlers have to be defined here.
	// The variable names have to match the fx:id names in the FXML file.
	// The @FXML tag lets the FXML loader object know where it needs to inject variables.

	// A TextField where the user enters the customer name.
	@FXML
	private TextField addOrderCustNameTxtField;

	// A Label to say what the addOrderCustNameTxtField is for.
	@FXML
	private Label addOrderCustNameLabel;

	// A TextArea where the user enters the order notes.
	@FXML
	private TextArea addOrderOrderNotesTxtArea;

	// ChoiceBox to allow choosing a table number for the order's destination table.
	@FXML
	private ChoiceBox<Integer> addOrderTableNumChoiceBox;

	// Button to clear all form fields in the AddOrder tab.
	@FXML
	private Button addOrderClearDraftBtn;

	// Button to submit new order.
	@FXML
	private Button addOrderSubmitOrderBtn;
	
	// ChoiceBox to choose menu.
	@FXML
	private ChoiceBox<String> menuChooser;
	
	// ChoiceBox to choose menu item category for selected menu.
	@FXML
	private ChoiceBox<String> categoryChooser;
	
	// ListView for selecting menuItems to add to order.
	@FXML
	private ListView menuItemsListView;
	
	// ListView for displaying menuItems added to order and for selecting items to remove.
	@FXML
	private ListView selectedItemsListView;

	// Label to display the order total based on all added menu items.
	@FXML
	private Label priceLabel;

	//location and resources will be injected by the FXML loader object
	@FXML
	private URL location;

	@FXML
	private ResourceBundle resources;

	//****************
	// Fields - other
	//****************
	
	//*****************
	// TABLES FIELDS
	//***************** 

	/* To store a deep copy of the Tables object
	 * used in the TablesController class.
	 * Whenever the user clicks the table number ChoiceBox,
	 * this object is updated.
	 */
	private Tables tables;

	// To store the numbers of all currently occupied tables
	private ArrayList<Integer> occupiedTableNums = new ArrayList<Integer>();

	// Observable ArrayList to store occupied tables's numbers for the table picker ChoiceBox.
	private ObservableList<Integer> occupiedTableNumsForCB = FXCollections.observableArrayList();

	//*****************
	// MENUS FIELDS
	//*****************
	
	// To store all current menus
	private ArrayList<menus> currentMenus = new ArrayList<menus>();
	
	// To store all currently active menus
	private ArrayList<menus> activeMenus = new ArrayList<menus>();
	
	// To store names of active menus for the ChoiceBox
	private ObservableList<String> activeMenuNamesForCB = FXCollections.observableArrayList();
	
	//*******************
	// MENU ITEMS FIELDS
	//*******************

	// list of all menus, where each menu (and a have a menu called all mapped to all items) mapped to an object cataegorizing the menu items (categories: All, drink, dessert, side, etc.)
	// hashmap of menu names mapped to lists of category names?
	
	// need observable lists for each category of menu items, for each menu

	// When a menu is selected,
	// grab categories for that menu
	// have the "All" category selected by default
	// When a category is selected (or is selected by default),
	// show that category's menu items in the list view selector
	
	// To store active menus and their items by category
	private CategoryTree activeMenusCategoryTree = new CategoryTree();
	
	// To store the menuItem caetgories for the selected menu
	private ObservableList<String> itemCategoriesForCB = FXCollections.observableArrayList();
	
	// To store Strings naming all menuItem categories for the selected menu
	private ArrayList<String> categoriesForSelectedMenu = new ArrayList<String>();
	
	// To store the currently selected menu in the menu chooser ChoiceBox
	private String selectedMenu = new String();
	
	// To store the most recently selected menuItem category (from the ChoiceBox)
	private String selectedCategory;
	
	// To store all selected menuItems for an order
	private ArrayList<menuItems> selectedItems = new ArrayList<menuItems>();
	
	// To store the order total price
	private double orderTotal;
	
	//**************************
	// Constructor
	//**************************

	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public AddOrderTabController() {
	}
	
	//**************************
	// Initialize
	//**************************
	
	/**
	 * This is where parts of this Controller's associated GUI can
	 * have things initialized before being displayed, and other things
	 * needed can be initialized here.
	 * 
	 * This method is needed by the FXMLLoader object.
	 */
	@FXML
	private void initialize() {	
		
		// Initialize the categoryTree of menus and items
		activeMenusCategoryTree = new CategoryTree();
		
		// Populate the meal selection 
		//for (int i =1; i<menu.menus_launcher.allMenus.size();i++)
		//{
			//menuChooser.getItems().addAll(menu.menus_launcher.allMenus.get(i).getMenuName());
		//}
		
	}

	//**************************
	// Event handlers
	//**************************

	/**
	 * Submits an order to the system database if all form fields contain input.
	 * 
	 * If any fields are missing input, the user is alerted and submission is denied.
	 * 
	 * When all fields contain input, the user is shown a confirmation box.
	 * If the user picks OK there, the system will submit an order, clear the
	 * add order form, and return the order's ID number to user in a popup.
	 * 
	 * Table number input allows for valid tables only (ones that currently are occupied - why
	 * would we want to assign an order to a table with no one there to eat the food and pay for it?)
	 * 
	 */
	@FXML
	public void submitOrder() {
		//TODO: Validate that all fields contain values before allowing user to confirm or cancel order submission

		// Check all fields for input and store result.
		boolean isInputValid = !addOrderCustNameTxtField.getText().isBlank() &&
				!addOrderOrderNotesTxtArea.getText().isBlank() &&
				(addOrderTableNumChoiceBox.getValue() != null) &&
				(selectedItems.size() > 0);
		//TODO: Implement validation for menu items.


		/* Alert to serve as order submission confirmation popup if all fields contain input
		 * or to alert the user that more input is needed if any fields are missing input.
		 */
		Alert submitAlert;

		// If the necessary input has been provided, prompt for confirmation to submit the order.
		// If the user chooses OK, submit the order. Otherwise, do nothing.
		if (isInputValid) {

			// Set the Alert to be a Confirmation Alert, since we need to get the user's confirmation.
			submitAlert = new Alert(AlertType.CONFIRMATION);

			// Set up the Alert text.
			submitAlert.setTitle("Submit New Order");
			submitAlert.setHeaderText("Confirm Submitting New Order");
			submitAlert.setContentText("Are you OK with this?");

			// Show the Alert, wait for input, and grab the button pressed by the user.
			Optional<ButtonType> submitOrderPopupResult1 = submitAlert.showAndWait();

			// If the user chose OK, submit the order and clear the form fields.
			if (submitOrderPopupResult1.get() == ButtonType.OK) {
				// If user confirms submitting order, submit order and clear form.

				//TODO: Submit new order to database
				// Put order submission code here
				try {
					String timestamp = getTimestamp();
					
					ConnectDB.orderStmnts.executeAddOrder(0, // Add 0 so that a unique order ID number is automatically generated
							addOrderCustNameTxtField.getText(), // Add the customer name
							addOrderTableNumChoiceBox.getValue().intValue(), // Add the table number
							addOrderOrderNotesTxtArea.getText(), // Add the order notes
							timestamp, // Add the timestamp
							OrderState.NEW.name(), // Add the order status (NEW is default)
							generateItemsCSV(), // Add the menu items
							0, // Add 0 (means false; that the order has not been updated)
							""); // Add an empty String (this space would store commas-separated timestamps for each time the order has been updated)
					
					// Get what should be the most recent submission's (so the just-added order's) ID number.
					int submissionIdNum = ConnectDB.orderStmnts.getLatestOrderID();
							
					// Clear form
					addOrderCustNameTxtField.clear();
					addOrderOrderNotesTxtArea.clear();
					addOrderTableNumChoiceBox.setValue(null);
					menuChooser.setValue(null);
					categoryChooser.setValue(null);
					menuItemsListView.getItems().clear();
					selectedItems.clear();
					selectedItemsListView.getItems().clear();
					
					

					//TODO: Menu items should be cleared

					// Display submission success message

					// Set submitAlert to be a new Information Alert box.
					submitAlert = new Alert(AlertType.INFORMATION);

					// Set up the Alert box text.
					submitAlert.setTitle("Submission Successful");
					submitAlert.setHeaderText("New Order Successfully Submitted");
					submitAlert.setContentText("Order ID: #" + submissionIdNum + " submitted at " + timestamp + ".");

					// Show the submission message and wait for the user to dismiss it.
					submitAlert.showAndWait();
				} catch (SQLException e) {
					// Output statck trace.
					e.printStackTrace();
					
					// Show a user-facing error message.
					submitAlert = new Alert(AlertType.ERROR);
					submitAlert.setTitle("Error");
					submitAlert.setHeaderText("Order Submission Error");
					submitAlert.setContentText("An error occurred while attempting to submit the order. Please try again.");
				}
			}
		}

		/* If there's any missing input, make the Alert box a Notification. Deny order
		 * submission and let the user know they need to provide more information.
		 */
		else {
			// Set Alert to be a Notification box,
			submitAlert = new Alert(AlertType.INFORMATION);

			// Set up the Alert text.
			submitAlert.setTitle("Missing Input");
			submitAlert.setHeaderText("All fields must be filled before submitting");
			submitAlert.setContentText("Fill in all order information and try again.");

			// Show the Alert and wait for the user to dismiss it.
			submitAlert.showAndWait();
		}
	} // End of submitOrder()

	/**
	 * Clears add order form fields, but asks for confirmation first.
	 * 
	 * @param none
	 */
	@FXML
	public void clearForm() {

		/* Create an Alert box to ask for confirmation to clear form data. 
		 * Base code for alert box sourced from https://code.makery.ch/blog/javafx-dialogs-official/
		 */
		Alert clearFormAlert = new Alert(AlertType.CONFIRMATION);

		// Set up text for Alert box.
		clearFormAlert.setTitle("Clear Order Draft?");
		clearFormAlert.setHeaderText("Confirm Clearing All Form Data");
		clearFormAlert.setContentText("Are you OK with this? (irreversible)");

		// Show the Alert, wait for input, and grab the button pressed by the user.
		Optional<ButtonType> result = clearFormAlert.showAndWait();

		// If the user pressed OK, clear the order form.
		if (result.get() == ButtonType.OK) {
			// If user confirms clearing form, clear all text and fields.
			addOrderCustNameTxtField.clear();
			addOrderOrderNotesTxtArea.clear();
			addOrderTableNumChoiceBox.setValue(null);
			menuChooser.setValue(null);
			categoryChooser.setValue(null);
			menuItemsListView.getItems().clear();
			selectedItemsListView.getItems().clear();
			selectedItems.clear();
		}
	} // End of clearForm.
	
	//**************************
	// Other methods
	//**************************
	
	/**
	 * Returns a String describing the time the function was called.
	 * @return a String describing a timestamp.
	 */
	private String getTimestamp() {
		// To grab the current time
		LocalDateTime timestamp = LocalDateTime.now();
		
		// To format the timestamp 
		DateTimeFormatter stampFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss a");
		
		// Format the timestamp and return it
		return timestamp.format(stampFormatter);
	}

	/**
	 * Runs when the Add Order tab is selected; this method
	 * calls other functions that update various data used
	 * by the AddOrderTabController class.
	 */
	@FXML
	public void updateData() {
		//boolean debug = true;
		
		// Update menu data
		updateMenus();
		
		// Update table dataß
		updateTables();
	}
	
	//***************************************
	// TABLE DATA FUNCTIONS + EVENT HANDLERS
	//***************************************
	
	/**
	 * Method to update tables data and table ChoiceBox.
	 */
	@FXML
	private void updateTablesAndCB() {
		boolean debug = true;
		
		if (debug) {
			System.out.println("Updating tables...");
		}
		
		updateTables();  // Update occupied tables selection list.
		
		if (debug) {
			System.out.println("Updating tables ChoiceBox...");
		}
		
		updateTableChoiceBox(); // Update the table picker ChoiceBox.
		
		if (debug) {
			System.out.println("Done updating Tables data and ChoiceBox.");
		}
	}
	
	/**
	 * Method to have the add order controller update its list of tables.
	 */
	@FXML
	private void updateTables() {
		/* Update the local tables object to match
		 * the one in the TablesController.
		 */
		tables = TablesController.getTables();
		
		// Now we can update the list of occupied tables' numbers.
		updateNumsOfOccupiedTables();
	}
	
	/**
	 * Method to update the list of numbers
	 * identifying occupied tables that orders can be assigned to.
	 * (since orders should only be delivered to tables
	 *  where customers are sitting)
	 */
	private void updateNumsOfOccupiedTables() {	
		// Clear out all stored occupied table numbers before udpating
		occupiedTableNums.clear();
		
		Table current; // To store current table being observed
		
		// Go through all tables and find the occupied ones
		for (int i = 0; i < tables.getTables().size(); i++) {
			current = tables.getTables().get(i);
			
			/* If the current table is occupied, add it to the 
			 * ArrayList of tables that orders can be assigned to
			 */
			if (current.getStatus() == tableStatus.OCCUPIED) {
				occupiedTableNums.add(current.getTableNumber());
			}
		}
	}
	
	/**
	 * Updates the values for the table picker ChoiceBox.
	 */
	private void updateTableChoiceBox() {
		// Clear out the Observable ArrayList to avoid unexpected contents.
		occupiedTableNumsForCB.clear();
		
		// Also clear the ChoiceBox.
		addOrderTableNumChoiceBox.setValue(null);

		// Add the numbers of the occupied tables to the Observable ArrayList.
		occupiedTableNumsForCB.addAll(occupiedTableNums);

		// Set the table ChoiceBox's items.
		addOrderTableNumChoiceBox.setItems(occupiedTableNumsForCB);
	}
	
	//**********************************************
	// ACTIVE MENUS DATA FUNCTIONS + EVENT HANDLERS
	//**********************************************
	
	/**
	 * Method to update menus data and ChoiceBox.
	 */
	@FXML
	public void updateMenusAndCB() {
		boolean debug = false;
		
		if (debug) {
			System.out.println("Updating menus...");
		}
		
		updateMenus(); // Get active menus.
		
		if (debug) {
			System.out.println("Updating menu ChoiceBox...");
		}
		
		updateMenuChoiceBox(); // Update menus.
		
		if (debug) {
			System.out.println("Done updating Menus data and ChoiceBox.\n");
		}
	}
	
	/**
	 * Populates the activeMenus ArrayList with all currently existing active menus.
	 */
	private void updateMenus() {
		// Clear out the current menus list before updating
		currentMenus.clear();
		
		// Fill it with all current menus at time of call
		currentMenus.addAll(menu.menus_launcher.allMenus);
		
		// Update the list of current active menus
		updateListOfActiveMenus();
	}

	/**
	 * Method to update the list of active menus currently in existence.
	 * Also rebuilds the active menus CategoryTree.
	 */
	private void updateListOfActiveMenus() {
		// Clear out the active menus before updating
		activeMenus.clear();
		
		// Go through all current menus and add the active menus to the active menus list
		for (int i = 0; i < currentMenus.size(); i++) {
			if (currentMenus.get(i).getMenuActivity()) {
				activeMenus.add(currentMenus.get(i));
			}
		}
		
		// Rebuild the active menus CategoryTree
		activeMenusCategoryTree.rebuildCategoryTree(activeMenus);
	}
	
	/**
	 * This function is to make sure the list of active menus
	 * to add items to is always up to date in case menus are changed.
	 */
	@FXML
	private void updateMenuChoiceBox() {
		boolean debug = false;
		
		if (debug) {
			System.out.println("Clearing active menu names ObservableList...");
		}
		
		// Clear the menus ChoiceBox to remove possibility of having duplicates
		activeMenuNamesForCB.clear();
		
		if (debug) {
			System.out.println("Clearing menu ChoiceBox...");
		}
		
		// Clear the menu chooser choice box
		menuChooser.setValue(null);

		if (debug) {
			System.out.println("Populating active menu names ObservableList...");
		}
		
		// Populate the active menus ObservableArrayList with the active menus's names
		activeMenuNamesForCB.addAll(activeMenusCategoryTree.getMenuNames());
		
		if (debug) {
			System.out.println("Setting menu ChoiceBox to show active menu names from ObservableList...");
		}
		
		// Set the ChoiceBox to show the active menu names
		menuChooser.setItems(activeMenuNamesForCB);
		
		if (debug) {
			System.out.println("Done updating menu ChoiceBox.");
		}
	}

	//********************************************
	// MENU ITEMS DATA FUNCTIONS + EVENT HANDLERS
	//********************************************
	
	/**
	 * Updates both the list of menuItem categories for the selected menu
	 * and also the ChoiceBox that shows the categories to the user.
	 */
	public void updateCategoriesAndCB() {
		
		updateCategories();
		
		updateCategoriesChoiceBox();
	}
	
	/**
	 * Update the list of item categories for the selected menu.
	 */
	private void updateCategories() {
		// Clear out the categories ArrayList to avoid persistent items.
		categoriesForSelectedMenu.clear();
		
		boolean debug = true;
		
		// Get the name of the currently selected menu from the menu chooser ChoiceBox
		selectedMenu = menuChooser.getValue();
		
		if (debug) {
			System.out.println("The selected menu name is: " + selectedMenu + "\n");
		}
		
		// Get the menuItem categories for that menu, if it exists in the CategoryTree (it should)
		Hashtable<String, ArrayList<menuItems>> selectedMenusCategories = activeMenusCategoryTree.getSpecifiedMenusCategories(selectedMenu);
		
		if (debug) {
			System.out.println("The retrieved menu categories Hashtable is: " + selectedMenusCategories + "\n");
		}
		
		/* If the Hashtable is null and/or has no categories in it (so the user has picked an empty menu),
		 * put a String saying the menu is empty in the categories list so the user knows.
		 */
		if (selectedMenusCategories == null || selectedMenusCategories.isEmpty()) {
			categoriesForSelectedMenu.add("Selected menu is empty");
		}
		// Otherwise, get the names of each category and add them to the category names list.
		else {
			// Get an enumeration containing the names of each menuItem category
			Enumeration<String> categories = selectedMenusCategories.keys();

			/* While there are unseen category names, save category names for the selected
			 * menu into the menuItem categories ArrayList.
			 */
			while (categories.hasMoreElements()) {

				// Add the next unseen category name to the ArrayList
				categoriesForSelectedMenu.add(categories.nextElement());
			}
		}
				
	}
	
	/**
	 * Update the ChoiceBox that displays menuItem categories for the selected menu.
	 */
	private void updateCategoriesChoiceBox() {
		// Clear the ObservableList for the selected menu's item categories
		itemCategoriesForCB.clear();
		
		// Clear the ChoiceBox value
		categoryChooser.setValue(null);
		
		// Add the currently selected menu's categories to the ObservableList
		itemCategoriesForCB.addAll(categoriesForSelectedMenu);
		
		// Populate the ChoiceBox with the up-to-date item categories
		categoryChooser.setItems(itemCategoriesForCB);
	}
	
	/**
	 * The select method allows the user to select menuItems from a list to add to the order.
	 */
	@FXML
	private void selectItem() 
	{
		//creates a string of the selected item
		String selected = menuItemsListView.getSelectionModel().getSelectedItem().toString();

		//adds that item to the selected list
		selectedItemsListView.getItems().addAll(selected);
		
		// Break apart the selected item String to get the item details
		String[] info = breakApartItemString(selected);

		for (int i = 0; i < info.length; i++) {
			System.out.println(info[i] + "\n");
		}
		
		String item = info[0].strip();
		String menu = info[3].strip();
		String category = info[2].strip();

		// Find the item to add from the selectedItems ArrayList
		menuItems toAdd = new menuItems("", "", "", "", "");;
		
		toAdd = findItem(item, menu, category);

		//List<menuItems> items = menus_launcher.getMenu(menu).getMenuItems();
		
		//menuItems current;
		
		//for (int j = 0; j < items.size(); j++) {
		//	current = items.get(j);
			
		//	if (current.getItem().strip() == item) {
		//		toAdd = new menuItems(current);
		//	}
		//}
		
		System.out.println("Here is the item to add: " + toAdd.getItem());
		
		// Add the item if it has been found
		selectedItems.add(new menuItems(toAdd));
		
		// Calculate the order price
		calculatePrice();
	}
	
	/**
	 * The remove method allows the user to remove items from the selected list
	 * in the event they added the wrong item or one they don't want to the selected list.
	 */
	@FXML
	private void removeItem()
	{
		// Creates a string of the selected item
		String selected = selectedItemsListView.getSelectionModel().getSelectedItem().toString();

		// Removes the item from the selected list
		selectedItemsListView.getItems().remove(selected);
		
		// Break apart the selected item String to get the item details
		String[] info = breakApartItemString(selected);

		for (int i = 0; i < info.length; i++) {
			System.out.println(info[i] + "\n");
		}

		String item = info[0].strip();
		//String menu = info[3].strip();
		String category = info[2].strip();

		// Find the item to remove from the selectedItems ArrayList	
		menuItems toRemove = null;
		
		menuItems curr;
		
		// Find the item to remove
		for (int j = 0; j < selectedItems.size(); j++) {
			curr = selectedItems.get(j);
			
			if (curr.getItem().strip().equals(item)) {
				toRemove = curr;
				
				break;
			}
		}
		
		System.out.println(toRemove.getItem());
		
		// Remove the item if it has been found
		selectedItems.remove(toRemove);
		
		// Calculate the order price
		calculatePrice();
	}
	
	/**
	 * Get the specified menuItem if it exists.
	 * @param name - String saying name of item to grab.
	 * @param menu - String saying menu to grab item from.
	 * @param category - String saying category that item is in.
	 * @return The item if it exists, or null otherwise.
	 */
	private menuItems findItem(String name, String menu, String category) {
		name = name.strip();
		menu = menu.strip();
		category = category.strip();
		
		menuItems item = null; // To hold found item
		
		menuItems currItem; // To hold current item
		
		String currItemName;
		
		// Get items from specified menu and category
		//TODO: fix getSpecifiedMenuCategorysItems() not returning all items for the given category
		ArrayList<menuItems> items = activeMenusCategoryTree.getSpecifiedMenuCategorysItems(menu, category);
		
		System.out.println("Length of items list from menu " + menu + " and category " + category + ": " +items.size());
		
		// Look for the given item
		if (items != null) {
			for (int i = 0; i < items.size(); i++) {
				currItem = items.get(i);

				currItemName = currItem.getItem().strip();
				
				System.out.println("Item at index " + i + ": " + currItemName);
				
				if (currItemName.equals(name)) {
					System.out.println("Item found!");
					
					//item = new menuItems(currItem); // Copy it.
					
					item = currItem;

					break; // Stop looping once it has been found
				}
			}
		} // If the item hasn't been found, item will stay null.
		
		return item; // Return the item (or null if it hasn't been found)
	}
	
	/**
	 * Breaks apart a String from the menuItem picker lists into useful bits of info.
	 * @param item - The String for a menuItems to break up.
	 * @return - A String Array with each bit of info riding along separately.
	 */
	private String[] breakApartItemString(String item) {
		String[] itemInfo;
		
		// Split that String!
		// Index - Info
		//  0 - item name
		//  1 - item price
		//  2 - item category
		//  3 - item menu
		//  4 - item description
		itemInfo = item.split("\t");
		
		return itemInfo;
	}
	
	/**
	 * Calculates the price of an order, given an ArrayList of its menuItems.
	 */
	private void calculatePrice() {
		orderTotal = 0; // Intialize orderTotal to 0
		
		// To store current item to grab price from
		menuItems current;
		
		String currPrice;
		
		// Sum up all the prices
		for (int i = 0; i < selectedItems.size(); i++) {
			current = selectedItems.get(i);
			
			currPrice = current.getPrice();
			
			if (currPrice.contains("$")) {
				currPrice = currPrice.substring(1);
			}
			else {
				currPrice = "0.0";
			}
			
			orderTotal += Double.parseDouble(currPrice);
		}
		
		// Set the label to show the price
		priceLabel.setText("$" + Double.toString(orderTotal));
	}
	
	/**
	 * The populate selections method makes sure that, for the selected
	 * menu and menuItems category, the fields are populated so that they can be changed if needed.
	 * This method applies to the ListView for items being presented for selection.
	 */
	@FXML 
	private void populateListSelections()
	{
		// Making sure the ListView is clear
		menuItemsListView.getItems().clear();

		selectedCategory = categoryChooser.getValue();
		
		ArrayList<menuItems> items;
		
		if (selectedMenu != null && selectedCategory != null) {
			items = activeMenusCategoryTree.getSpecifiedMenuCategorysItems(selectedMenu, selectedCategory);
		}
		else {
			items = new ArrayList<menuItems>();
			
			items.add(null);
		}
		
		menuItems current;
		
		String currentStr;
		
		//populating all the items for possible additions
		for (int i = 0; i < items.size(); i++)
		{
			current = items.get(i);
			
			// Include some ordered info so that this String can be split into useful individual bits:
			// Index - Info
			//  0 - item name
			//  1 - item price
			//  2 - item category
			//  3 - item menu
			//  4 - item descriptio
			currentStr = current.getItem() + "\t" + current.getPrice() + "\t" + current.getCategory() + "\t" + selectedMenu + "\t" + current.getDescription();
			
			menuItemsListView.getItems().add(currentStr);
		}
	}
	
	/**
	 * Generate a CSV String of all menuItems in the order.
	 * @return a String with comma-separateed names of all ordered items.
	 */
	public String generateItemsCSV() {
		String CSV = "";
		
		menuItems curr;
		
		// Build up the String.
		for (int i = 0; i < selectedItems.size(); i++) {
			curr = selectedItems.get(i);
			
			CSV += curr.getItem() + ",";
		}
		
		return CSV;
	}

	
} // End of AddOrderTabController