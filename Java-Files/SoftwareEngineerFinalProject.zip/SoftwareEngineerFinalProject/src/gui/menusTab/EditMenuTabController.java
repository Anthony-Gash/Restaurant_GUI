package gui.menusTab;

import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

//edit menu tab controller class
public class EditMenuTabController {
	
	//creating a variable to correlate with the variables in the fxml file
	@FXML
	private Button finshButton;
	
	@FXML
	private Button selectButton1;
	
	@FXML
	private Button removeButton1;
	
	@FXML
	private ListView<String> items1;
	
	@FXML
	private TextField menuName1;
	
	@FXML
	private ListView<String> selectedItems1;
	
	@FXML
	private RadioButton activeSelection1;
	
	@FXML 
	private ChoiceBox<String> mealSelection;
	
	@FXML
	private URL location;
	
	@FXML
	private ResourceBundle resources;
	
	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public EditMenuTabController() {
	}
	
	/**
	 * This is a private method with a void return
	 * type, and is needed by the FXML loader object. In this instance, 
	 * I have the menu set to populate as well as the creation and formatting of the columns
	 * @throws FileNotFoundException 
	 */
	@FXML
	private void initialize()
	{
		for (int i=0;i<menu.menus_launcher.allMenus.size();i++)
		{
			mealSelection.getItems().addAll(menu.menus_launcher.allMenus.get(i).getMenuName());
		}
	}
	
	//select method
	//allows the user to select items from a list to add to the menu
	@FXML
    private void select() 
	{
		//creates a string of the selected item
        String selected = items1.getSelectionModel().getSelectedItem();
        
        //removes that item from the total list
        items1.getItems().remove(selected);
        
        //adds that item to the selected list
        selectedItems1.getItems().addAll(selected);
    }
	
	//remove method
	//allows the user to remove items from the selected list
	//in the event they added the wrong item to the selected list
	@FXML
	private void remove()
	{
		//creates a string of the selected item
		String selected = selectedItems1.getSelectionModel().getSelectedItem();
		
		//removes the item form the selected list
		selectedItems1.getItems().remove(selected);
        
        //adds that item back to the total list
		items1.getItems().addAll(selected);
	}
	
	//update menus function
	//runs when the user switches tabs
	//the purpose is to make sure the list of possible menus to edit is always up to date in the 
	//event a menu is added or deleted
	@FXML
	private void updateMenus()
	{
		mealSelection.getItems().clear();
		for (int i=0;i<menu.menus_launcher.allMenus.size();i++)
		{
			mealSelection.getItems().addAll(menu.menus_launcher.allMenus.get(i).getMenuName());
		}
	}
	
	//populate selections method
	//from the selected menu, the fields are populated so that they can be changed if needed
	@FXML 
	private void populateSelections()
	{
		//making sure the fields are clear
		items1.getItems().clear();
		selectedItems1.getItems().clear();
		
		//populating all the items for possible additions
		for (int i = 0;i < menu.menuItem_launcher.allMenuItems.size();i++)
		{
			items1.getItems().addAll(menu.menuItem_launcher.getAllItems().get(i).getItem());
		}
		
		//populating items already selected for the menu and removing them from the all items list
		//so there isn't a chance to add two of the same item
		for (int j = 0; j<menu.menus_launcher.getMenu(mealSelection.getValue().toString()).getMenuItems().size(); j++)
		{
			selectedItems1.getItems().addAll(menu.menus_launcher.getMenu(mealSelection.getValue().toString()).getMenuItems().get(j).getItem());
			items1.getItems().remove(menu.menus_launcher.getMenu(mealSelection.getValue().toString()).getMenuItems().get(j).getItem());
		}
		
		//populating the menu name
		menuName1.setText(menu.menus_launcher.getMenu(mealSelection.getValue().toString()).getMenuName());
		
		//populating the menu activeness
		activeSelection1.setSelected(menu.menus_launcher.getMenu(mealSelection.getValue().toString()).getMenuActivity());
	}
	
	//finish method
	//takes all the updated information and updates the selected menu
	@FXML
	private void finish()
	{
		//updates the menu activeness
		menu.menus_launcher.getMenu(mealSelection.getValue().toString()).setMenuActivity(activeSelection1.isSelected());
		//creates a list of the updated items
		List <menu.menuItems> updatedItems = new ArrayList<menu.menuItems>();
		//converts the string item names to menu items and adds them to the update items list
		for (int i =0;i<selectedItems1.getItems().size();i++)
		{
			updatedItems.add(menu.menuItem_launcher.getItem(selectedItems1.getItems().get(i).toString()));
		}
		
		//updates the menu items
		menu.menus_launcher.getMenu(mealSelection.getValue().toString()).setMenuItems(updatedItems);
		//updates the menu name
		menu.menus_launcher.getMenu(mealSelection.getValue().toString()).setMenuName(menuName1.getText().strip());
		
		//creating the alert box
		Alert confirmationBox;
		confirmationBox = new Alert(AlertType.INFORMATION);

		// Set up the Alert text.
		confirmationBox.setTitle("Success");
		confirmationBox.setHeaderText("All Changes have been saved");
		
		//showing the alert box
		confirmationBox.showAndWait();
		
		//clearing the fields
		selectedItems1.getItems().clear();
		menuName1.clear();
		updateMenus();

	}
	
}