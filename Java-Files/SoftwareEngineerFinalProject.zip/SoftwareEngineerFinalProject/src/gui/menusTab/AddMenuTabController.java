package gui.menusTab;


import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

//add menu tab controller class
public class AddMenuTabController {
	
	//creating a variable to correlate with the variables in the fxml file
	@FXML
	private Button createButton;
	
	@FXML
	private Button selectButton;
	
	@FXML
	private Button removeButton;
	
	@FXML
	private ListView<String> items;
	
	@FXML
	private TextField menuName;
	
	@FXML
	private ListView<String> selectedItems;
	
	@FXML
	private RadioButton activeSelection;
	
	@FXML
	private URL location;
	
	@FXML
	private ResourceBundle resources;
	
	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public AddMenuTabController() {
	}
	
	/**
	 * This is a private method with a void return
	 * type, and is needed by the FXML loader object. In this instance, 
	 * I have the menu set to populate as well as the creation and formatting of the columns
	 * @throws FileNotFoundException 
	 */
	@FXML
	private void initialize()
	{
		//populating all the possible items to add to the menus
		for (int i = 0; i<menu.menuItem_launcher.allMenuItems.size();i++)
		{
			items.getItems().add(menu.menuItem_launcher.allMenuItems.get(i).getItem());
		}
	}
	
	//select method
	// allows the user to select items from a list to add to the menu
	@FXML
    private void select() 
	{
		//creates a string of the item selected
        String selected = items.getSelectionModel().getSelectedItem();
        
        //removes that item from the total list
        items.getItems().remove(selected);
        
        //adds that item to the selected list
        selectedItems.getItems().addAll(selected);
    }
	
	//remove method
	//allows the user to remove items from the selected list
	//in the event they added the wrong item to the selected list
	@FXML
	private void remove()
	{
		//creates a string of the item selected
		String selected = selectedItems.getSelectionModel().getSelectedItem();
		
		//removes the item from the selected list
		selectedItems.getItems().remove(selected);
        
        //adds that item back to the total list
		items.getItems().addAll(selected);
	}
	
	//create function
	//first provides error checking to make sure all the needed information is provided
	@FXML
	private void create()
	{
		//checks to see if the name field is empty
		if (menuName.getText().isEmpty()) 
		{
			//creating the alert box
			Alert noName;
			noName = new Alert(AlertType.ERROR);

			// Set up the Alert text.
			noName.setTitle("ERROR");
			noName.setHeaderText("Please Enter a Name for the Menu");
			
			//showing the alert box
			noName.showAndWait();
		}
		//checks to see if the selected items field is empty
		else if (selectedItems.getItems().size() == 0)
		{
			//creating the alert box
			Alert noItems;
			noItems = new Alert(AlertType.ERROR);

			// Set up the Alert text.
			noItems.setTitle("ERROR");
			noItems.setHeaderText("Please Select Items for the Menu");
			
			//showing the alert box
			noItems.showAndWait();
		}
		//executes if all fields are filled in
		else
		{
			//creates a temporary list of menu items
			List <menu.menuItems> temp = new ArrayList<menu.menuItems>();
			for (int i=0; i<selectedItems.getItems().size();i++)
			{
				//converts the string name to a menu item and adds it to the list
				temp.add(menu.menuItem_launcher.getItem(selectedItems.getItems().get(i)));
			}
			//creates a new menu based on the inputed text, list of items, and the activity selection
			menu.menus_launcher.createMenu(menuName.getText().strip(), temp, activeSelection.isSelected());
			
			//creating the alert box
			Alert menuCreation;
			menuCreation = new Alert(AlertType.INFORMATION);

			// Set up the Alert text.
			menuCreation.setTitle("Success");
			menuCreation.setHeaderText("The Menu, " + menuName.getText() + ", Has Been Created");
			
			//showing the alert box
			menuCreation.showAndWait();
			
			//clears all the fields
			items.getItems().addAll(selectedItems.getItems());
			selectedItems.getItems().clear();
			menuName.clear();
			activeSelection.setSelected(false);
			
		}
	}
	
}