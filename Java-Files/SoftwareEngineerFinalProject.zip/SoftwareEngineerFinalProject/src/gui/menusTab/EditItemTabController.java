package gui.menusTab;

import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;


//edit item tab controller class
public class EditItemTabController {
	
	//creating a variable to correlate with the variables in the fxml file
	@FXML
	private Button saveButton;

	@FXML
	private TextField itemNameTxtField1;
	
	@FXML
	private TextField itemPriceTxtField1;
	
	@FXML
	private TextField itemCategoryTxtField1;
	
	@FXML
	private TextArea itemDescriptionTxtField1;
	
	@FXML
	private ChoiceBox<String> itemMealSelection1;
	
	@FXML
	private ListView<String> itemsList;
	
	@FXML
	private TextField searchBar;
	
	private ObservableList<String> searchItemList = FXCollections.observableArrayList();
	
	@FXML
	private URL location;
	
	@FXML
	private ResourceBundle resources;
	
	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public EditItemTabController() {
	}
	
	/**
	 * This is a private method with a void return
	 * type, and is needed by the FXML loader object. In this instance, 
	 * I have the menu set to populate as well as the creation and formatting of the columns
	 * @throws FileNotFoundException 
	 */
	@FXML
	private void initialize()
	{
		//populates the item list as well as the search item lest
		for (int i = 0; i < menu.menuItem_launcher.allMenuItems.size();i++)
		{
			searchItemList.add(menu.menuItem_launcher.allMenuItems.get(i).getItem());
			itemsList.getItems().add(menu.menuItem_launcher.allMenuItems.get(i).getItem());
		}
		
		//populates the meal selection with possible changes
		for (int i =1; i<menu.menus_launcher.allMenus.size();i++)
		{
			itemMealSelection1.getItems().addAll(menu.menus_launcher.allMenus.get(i).getMenuName());
		}
		
		//adds a listener to the search bar
		searchBar.textProperty().addListener((observable, oldValue, newValue) -> {
            // Filter the original list based on the search text
            filterList(newValue);
        });
	}
	
	//filter list method
	//the function that allows the user to search the list
	private void filterList(String searchText) {
        // If search text is empty, display the original list
        if (searchText == null || searchText.isEmpty()) {
        	itemsList.setItems(searchItemList);
            return;
        }
        
        // Filter the original list based on the search text
        ObservableList<String> filteredList = FXCollections.observableArrayList();
        for (String item : searchItemList) {
            if (item.toLowerCase().contains(searchText.toLowerCase())) {
                filteredList.add(item);
            }
        }
        
        // Update the ListView with the filtered list
        itemsList.setItems(filteredList);
    }
	
	//select function
	//based on the selected item, it auto fills the fields to be edited
	@FXML
	private void select()
	{
		//creating a temporary item for easier access
		menu.menuItems editItem = menu.menuItem_launcher.getItem(itemsList.getSelectionModel().getSelectedItem());
		
		//setting all the fields to the items values 
		itemNameTxtField1.setText(editItem.getItem());
		itemPriceTxtField1.setText(editItem.getPrice());
		itemCategoryTxtField1.setText(editItem.getCategory());
		itemDescriptionTxtField1.setText(editItem.getDescription());
		itemMealSelection1.setValue(editItem.getMeal());
	}
	
	//save function
	//takes in all the fields and sets them to the properties of the item
	@FXML
	private void save()
	{
		//creating a temporary item for easier access
		menu.menuItems editItem = menu.menuItem_launcher.getItem(itemsList.getSelectionModel().getSelectedItem());
		
		//saving the previous menu 
		String prevMenu = editItem.getMeal();
		
		//setting the fields to entered/altered/remaining values
		editItem.setItem(itemNameTxtField1.getText().strip());
		editItem.setPrice(itemPriceTxtField1.getText().strip());
		editItem.setCategory(itemCategoryTxtField1.getText().strip());
		editItem.setDescription(itemDescriptionTxtField1.getText().strip());
		editItem.setMeal(itemMealSelection1.getValue().strip());
		
		//checking to see if the meal changed
		if (!prevMenu.equals(editItem.getMeal()))
		{
			//if the meal changed, it removes the item from the previous meal list and adds it to the new one
			menu.menus_launcher.getMenu(prevMenu).getMenuItems().remove(editItem);
			menu.menus_launcher.getMenu(editItem.getMeal()).getMenuItems().add(editItem);
		}
		
		//creating the alert box
		Alert confirmationBox;
		confirmationBox = new Alert(AlertType.INFORMATION);

		// Set up the Alert text.
		confirmationBox.setTitle("Success");
		confirmationBox.setHeaderText("All Changes have been saved");
		
		//showing the alert box
		confirmationBox.showAndWait();
		
		//clearing all the fields
		itemNameTxtField1.clear();
		itemPriceTxtField1.clear();
		itemCategoryTxtField1.clear();
		itemDescriptionTxtField1.clear();
		itemMealSelection1.getItems().clear();
		
		//resetting the meal selection choice box
		for (int i =1; i<menu.menus_launcher.allMenus.size();i++)
		{
			itemMealSelection1.getItems().addAll(menu.menus_launcher.allMenus.get(i).getMenuName());
		}
		
		//clearing the search list and items list
		searchItemList.clear();
		itemsList.getItems().clear();
		
		//updating the search list and item list
		for (int i = 0; i < menu.menuItem_launcher.allMenuItems.size();i++)
		{
			searchItemList.add(menu.menuItem_launcher.allMenuItems.get(i).getItem());
			itemsList.getItems().add(menu.menuItem_launcher.allMenuItems.get(i).getItem());
		}
		
	}
	
	//update choices function
	//runs when the user switches tabs
	//the purpose is to make sure the list of possible items to edit is always up to date in the 
	//event an item is added
	@FXML
	private void updateItems()
	{
		//clears the lists
		searchItemList.clear();
		itemsList.getItems().clear();
		
		//populates the list view and search bar list
		for (int i = 0; i < menu.menuItem_launcher.allMenuItems.size();i++)
		{
			itemsList.getItems().add(menu.menuItem_launcher.allMenuItems.get(i).getItem());
			searchItemList.add(menu.menuItem_launcher.allMenuItems.get(i).getItem());
		}
		
		//clears the choice box
		itemMealSelection1.getItems().clear();
		
		//populates the choice box with all the menus
		for (int i=1;i<menu.menus_launcher.allMenus.size();i++)
		{
				itemMealSelection1.getItems().addAll(menu.menus_launcher.allMenus.get(i).getMenuName());
		}
	}
	
}