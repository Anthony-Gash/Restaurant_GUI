package gui.menusTab;

import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

//menu tab controller class
public class ViewMenusTabController {
	
	//creating a variable to correlate with the variables in the fxml file
	@FXML
	public ComboBox<String> mealSelection;

	@FXML
	private TableView<menu.menuItems> menuTable;
	
	@FXML
	private URL location;
	
	@FXML
	private ResourceBundle resources;
	
	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public ViewMenusTabController() {
	}
	
	/**
	 * This is a private method with a void return
	 * type, and is needed by the FXML loader object. In this instance, 
	 * I have the menu set to populate as well as the creation and formatting of the columns
	 * @throws FileNotFoundException 
	 */
	@FXML
	private void initialize()
	{
		//populating the all menu items list from the csv file
		menu.menuItem_launcher.populateMenu();
		
		//creates the 4 basic menu types (All, Breakfast, Lunch, and Dinner) and adds them to a list of menus
		menu.menus_launcher.populateMenus();	
		
		//populating the combo box with the names of the active menus
		for (int i =0; i <menu.menus_launcher.allMenus.size();i++)
		{
			if (menu.menus_launcher.allMenus.get(i).getMenuActivity() == true)
			{
				mealSelection.getItems().addAll(menu.menus_launcher.allMenus.get(i).getMenuName());	
			}
		}
		
		//creating the item column, setting the property value, and setting the width
		TableColumn<menu.menuItems, String> itemColumn = new TableColumn<>("Item");
		itemColumn.setCellValueFactory(new PropertyValueFactory<>("item"));
		itemColumn.setPrefWidth(184);

		//creating the price column, setting the property value, and setting the width
		TableColumn<menu.menuItems, String> priceColumn = new TableColumn<>("Price");
		priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
		priceColumn.setPrefWidth(78);
		
		//creating the description column, setting the property value, and setting the width
		TableColumn<menu.menuItems, String> descriptionColumn = new TableColumn<>("Description");
		descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
		descriptionColumn.setPrefWidth(1080);
		
		//creating the category column, setting the property value, and setting the width
		TableColumn<menu.menuItems, String> categoryColumn = new TableColumn<>("Category");
		categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
		categoryColumn.setPrefWidth(187);
		
		//creating the meal column, setting the property value, and setting the width
		TableColumn<menu.menuItems, String> mealColumn = new TableColumn<>("Meal");
		mealColumn.setCellValueFactory(new PropertyValueFactory<>("meal"));
		mealColumn.setPrefWidth(72);

		//adding all the columns to the menu table
		menuTable.getColumns().addAll(categoryColumn, itemColumn, priceColumn,descriptionColumn,mealColumn );
		

	}
	
	//update choices function
	//runs when the user switches tabs
	//the purpose is to make sure the list of possible menus to view is always up to date in the 
	//event a menu is added or deleted
	@FXML
	public void updateChoices()
	{
		//clearing the combo box
		mealSelection.getItems().clear();
		
		//populating the combo box with all active menus
		for (int i =0; i <menu.menus_launcher.allMenus.size();i++)
		{
			if (menu.menus_launcher.allMenus.get(i).getMenuActivity() == true)
			{
				mealSelection.getItems().addAll(menu.menus_launcher.allMenus.get(i).getMenuName());	
			}
		}
	}
	
	//Select function
	//takes the value selected from the combo box, and displays the correct menu
	@FXML
	private void select()
	{
		//creates an observable list
		ObservableList<menu.menuItems> items = FXCollections.observableArrayList();
		for (int j = 0; j < menu.menus_launcher.getMenu(mealSelection.getValue()).getMenuItems().size();j++)
		{
			//adds the needed items to the observable list
			items.add(menu.menus_launcher.getMenu(mealSelection.getValue()).getMenuItems().get(j));
		}

		//adds the observable list to the menu table
		menuTable.setItems(items);
	
		
	}
	
}