package gui.menusTab;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;


//add item tab controller class
public class DeleteItemTabController {
	
	//creating a variable to correlate with the variables in the fxml file
	@FXML
	private Button deleteButton;
	
	@FXML
	private TextField searchBar;
	
	@FXML
	private ListView<String> itemListView;
	
	private ObservableList<String> searchItemList = FXCollections.observableArrayList();
	
	@FXML
	private URL location;
	
	@FXML
	private ResourceBundle resources;
	
	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public DeleteItemTabController() {
	}
	
	/**
	 * This is a private method with a void return
	 * type, and is needed by the FXML loader object. In this instance, 
	 * I have the menu set to populate as well as the creation and formatting of the columns
	 * @throws FileNotFoundException 
	 */
	@FXML
	private void initialize()
	{
		//populates the item list as well as the search item lest
		for (int i = 0; i < menu.menuItem_launcher.allMenuItems.size();i++)
		{
			searchItemList.add(menu.menuItem_launcher.allMenuItems.get(i).getItem());
			itemListView.getItems().add(menu.menuItem_launcher.allMenuItems.get(i).getItem());
		}
		
		//adds a listener to the search bar
		searchBar.textProperty().addListener((observable, oldValue, newValue) -> {
            // Filter the original list based on the search text
            filterList(newValue);
        });
	}
	
	//filter list method
	//the function that allows the user to search for items
	private void filterList(String searchText) {
        // If search text is empty, display the original list
        if (searchText == null || searchText.isEmpty()) {
        	itemListView.setItems(searchItemList);
            return;
        }
        
        // Filter the original list based on the search text
        ObservableList<String> filteredList = FXCollections.observableArrayList();
        for (String item : searchItemList) {
            if (item.toLowerCase().contains(searchText.toLowerCase())) {
                filteredList.add(item);
            }
        }
        
        // Update the ListView with the filtered list
        itemListView.setItems(filteredList);
    }
	
	//delete function
	//checks to make sure there is a selected item then removes it from the global item list and the menu it 
	//belongs to
	@FXML
	private void delete()
	{
		//if statement to make sure an item has been selected
		if (itemListView.getSelectionModel().getSelectedItem() == null)
		{
			//creating the alert box
			Alert noItem;
			noItem = new Alert(AlertType.ERROR);

			// Set up the Alert text.
			noItem.setTitle("ERROR");
			noItem.setHeaderText("Please Select an Item to be Deleted");
			
			//showing the alert box
			noItem.showAndWait();
		}
		else
		{
			//creating the alert box
			Alert deleteItemBox;
			deleteItemBox = new Alert(AlertType.CONFIRMATION);
	
			// Set up the Alert text.
			deleteItemBox.setTitle("IMPORTANT");
			deleteItemBox.setHeaderText("Are you sure you want to delete this item?\nThis action CANNOT be undone.");
			deleteItemBox.setContentText("Press \"OK\" to continue.\n"+
												"Otherwise press cancel.");
			//showing the alert box
			//prompts the user to hit "ok" to confirm their decision
			Optional<ButtonType> overwriteButton = deleteItemBox.showAndWait();
			
			//if the user hits "ok"
			if (overwriteButton.get() == ButtonType.OK)
			{
				//gets the name for the selected item
				String deleteItem = itemListView.getSelectionModel().getSelectedItem();
				
				//removes the item from the menu it belongs to
		        menu.menus_launcher.getMenu(menu.menuItem_launcher.getItem(deleteItem).getMeal()).getMenuItems().remove(menu.menuItem_launcher.getItem(deleteItem));
				
				//removes the item from the on screen list
				itemListView.getItems().remove(deleteItem);	
		        
		        //removes the item from the global item list
		        menu.menuItem_launcher.allMenuItems.remove(menu.menuItem_launcher.getItem(deleteItem));
		        	
			}
		}
	}
	
	//update choices function
	//runs when the user switches tabs
	//the purpose is to make sure the list of possible items to delete is always up to date in the 
	//event an item is added
	@FXML
	private void updateItems()
	{
		//clears the lists
		searchItemList.clear();
		itemListView.getItems().clear();
		
		//populates the list view and search bar list
		for (int i = 0; i < menu.menuItem_launcher.allMenuItems.size();i++)
		{
			itemListView.getItems().add(menu.menuItem_launcher.allMenuItems.get(i).getItem());
			searchItemList.add(menu.menuItem_launcher.allMenuItems.get(i).getItem());
		}
	}
	
}