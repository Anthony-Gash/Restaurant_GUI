package gui.menusTab;

import java.io.FileNotFoundException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;

//delete menu tab controller class
public class DeleteMenuTabController {
	
	//creating a variable to correlate with the variables in the fxml file
	@FXML
	private Button deleteButton;
	
	@FXML
	private ListView<String> allMenus;
	
	
	@FXML
	private URL location;
	
	@FXML
	private ResourceBundle resources;
	
	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public DeleteMenuTabController() {
	}
	
	/**
	 * This is a private method with a void return
	 * type, and is needed by the FXML loader object. In this instance, 
	 * I have the menu set to populate as well as the creation and formatting of the columns
	 * @throws FileNotFoundException 
	 */
	@FXML
	private void initialize()
	{
		//populates the possible menus to be deleted
		for (int i=0;i<menu.menus_launcher.allMenus.size();i++)
		{
			allMenus.getItems().addAll(menu.menus_launcher.allMenus.get(i).getMenuName());
		}
	}
	
	//delete method
	//checks to make sure a menu has been selected then deletes the desired menu
	@FXML
	private void delete()
	{
		//if statement to make sure a menu has been selected
		if (allMenus.getSelectionModel().getSelectedItem() == null)
		{
			//creating the alert box
			Alert noMenu;
			noMenu = new Alert(AlertType.ERROR);

			// Set up the Alert text.
			noMenu.setTitle("ERROR");
			noMenu.setHeaderText("Please Select a Menu to be Deleted");
			
			//showing the alert box
			noMenu.showAndWait();
		}
		else
		{
			//creating the alert box
			Alert deleteMenuBox;
			deleteMenuBox = new Alert(AlertType.CONFIRMATION);
	
			// Set up the Alert text.
			deleteMenuBox.setTitle("IMPORTANT");
			deleteMenuBox.setHeaderText("Are you sure you want to delete this menu?\nThis action CANNOT be undone.");
			deleteMenuBox.setContentText("Press \"OK\" to continue.\n"+
												"Otherwise press cancel.");
			//showing the alert box
			//prompts the user to hit "ok" to confirm their decision
			Optional<ButtonType> overwriteButton = deleteMenuBox.showAndWait();
			
			//if the user hits "ok"
			if (overwriteButton.get() == ButtonType.OK)
			{
				//gets the name for the selected menu
				String deleteMenu = allMenus.getSelectionModel().getSelectedItem();
				
				//removes the menu from the on screen list
		        allMenus.getItems().remove(deleteMenu);	
		        
		        //removes the menu from the global menus list
		        menu.menus_launcher.allMenus.remove(menu.menus_launcher.getMenuIndex(deleteMenu));
			}
		}
    }
	
	//update menus function
	//runs when the user switches tabs
	//the purpose is to make sure the list of possible menus to delete is always up to date in the 
	//event a menu is added
	@FXML
	private void updateMenus()
	{
		//clears the list
		allMenus.getItems().clear();
		
		//populates the list with all the menus
		for (int i=0;i<menu.menus_launcher.allMenus.size();i++)
		{
			allMenus.getItems().addAll(menu.menus_launcher.allMenus.get(i).getMenuName());
		}
	}
	
	
}