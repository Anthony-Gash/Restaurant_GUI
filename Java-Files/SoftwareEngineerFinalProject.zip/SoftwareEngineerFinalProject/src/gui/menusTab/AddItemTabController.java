package gui.menusTab;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

//add item tab controller class
public class AddItemTabController {
	
	//creating a variable to correlate with the variables in the fxml file
	@FXML
	private Button createButton;
	
	@FXML
	private TextField itemNameTxtField;
	
	@FXML
	private TextField itemPriceTxtField;
	
	@FXML
	private TextField itemCategoryTxtField;
	
	@FXML
	private TextArea itemDescriptionTxtField;
	
	@FXML
	private ChoiceBox<String> itemMealSelection;
	
	@FXML
	private URL location;
	
	@FXML
	private ResourceBundle resources;
	
	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public AddItemTabController() {
	}
	
	/**
	 * This is a private method with a void return
	 * type, and is needed by the FXML loader object. In this instance, 
	 * I have the menu set to populate as well as the creation and formatting of the columns
	 * @throws FileNotFoundException 
	 */
	@FXML
	private void initialize()
	{
		//populating the meal selection 
		for (int i =1; i<menu.menus_launcher.allMenus.size();i++)
		{
			itemMealSelection.getItems().addAll(menu.menus_launcher.allMenus.get(i).getMenuName());
		}
		itemMealSelection.setValue("Select Meal");
	}
	
	//create function
	//first checks to make sure the fields are all filled in then creates the item, placing it
	//in the desired menu as well as the all menu list
	@FXML
	private void create()
	{
		//converting the fields to variables for easier reference
		String name = itemNameTxtField.getText().strip();
		String price = itemPriceTxtField.getText().strip();
		String category = itemCategoryTxtField.getText().strip();
		String description = itemDescriptionTxtField.getText().strip();
		String meal = itemMealSelection.getValue().strip();

		//checks to see if any of the fields are left empty
		if((name.isEmpty()) || (price.isEmpty()) ||
				(category.isEmpty()) || (description.isEmpty()) ||
				(meal.equals("Select Meal")))
		{
			//creating the alert box
			Alert requiredFields;
			requiredFields = new Alert(AlertType.ERROR);

			// Set up the Alert text.
			requiredFields.setTitle("ERROR");
			requiredFields.setHeaderText("Please Fill Out All Fields");
			
			//showing the alert box
			requiredFields.showAndWait();
		}
		else
		{
			//creates a new item with the provided details
			menu.menuItem_launcher.createItem(name, price, category, description, meal);
			
			//creating the alert box
			Alert successfulCreation;
			successfulCreation = new Alert(AlertType.ERROR);

			// Set up the Alert text.
			successfulCreation.setTitle("Success");
			successfulCreation.setHeaderText("The Item, "+ name +", Has Been Created And Added To The " 
			+ meal + " Menu.");
			
			//showing the alert box
			successfulCreation.showAndWait();
			
			//clears the field
			itemNameTxtField.clear();
			itemPriceTxtField.clear();
			itemCategoryTxtField.clear();
			itemDescriptionTxtField.clear();
			itemMealSelection.setValue(null);
		}
	}
	
	//update choices function
	//runs when the user switches tabs
	//the purpose is to make sure the list of possible menus to add items to is always up to date in the 
	//event a menu is added
	@FXML
	private void updateChoices()
	{
		//clears the choice box
		itemMealSelection.getItems().clear();
		
		//populates the choice box
		for (int i =1; i<menu.menus_launcher.allMenus.size();i++)
		{
			itemMealSelection.getItems().addAll(menu.menus_launcher.allMenus.get(i).getMenuName());
		}
	}
	
}