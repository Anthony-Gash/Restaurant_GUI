package gui.employeesTab;
import java.net.URL;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.util.Callback;

//view schedule tab controller class
public class ViewScheduleTabController {
	
	//creating variables to correlate with those from the fxml file
	@FXML
	private ListView<String> listEmps;
	
	@FXML
	private Button viewButton;
	
	@FXML
	private DatePicker date;
	

	
	
	@FXML
	private URL location;
	
	@FXML
	private ResourceBundle resources;
	
	public List<LocalDate> holidays = new ArrayList<LocalDate>();
	
	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public ViewScheduleTabController() {
	}
	
	/**
	 * This is a private method with a void return
	 * type, and is needed by the FXML loader object.
	 */
	@FXML
	private void initialize() 
	{	
		//creates a list of holiday dates for the years 2000-2030
		for (int i = 2000; i<=2030;i++)
		{
			holidays.add(LocalDate.of(i, Month.JANUARY, 1));
			holidays.add(LocalDate.of(i, Month.JULY, 4));
			holidays.add(LocalDate.of(i, Month.DECEMBER, 25));
		}
		
		//creating a cell factory to allow the calendar days to be set to a different color based on certain
		// parameters
		date.setDayCellFactory(new Callback<DatePicker, DateCell>() {
			@Override
			public DateCell call(DatePicker param) {
				return new DateCell(){
					@Override
					public void updateItem(LocalDate item, boolean empty) {
						super.updateItem(item, empty);

						if (!empty && item != null) {
							for (int i =1; i<employees.Schedule_launcher.schedules.size(); i++)
							{
								//if statement to set scheduled days to yellow
								if((employees.Schedule_launcher.schedules.get(i).getDay() == (item.getDayOfMonth())) &&
								(employees.Schedule_launcher.schedules.get(i).getMonth() == (item.getMonthValue())) &&
								(employees.Schedule_launcher.schedules.get(i).getYear() == (item.getYear())))
								{
									this.setStyle("-fx-background-color: #e8e830");
								}
							}
							//sets the day to blue if its a holiday
							if(holidays.contains(item))
							{
								this.setStyle("-fx-background-color: #4db8ff");

							}
							//sets the day to red if its a sunday		
							if (item.getDayOfWeek() == DayOfWeek.SUNDAY)
							{
								this.setStyle("-fx-background-color: #ff4d4d");
							}
						}
					}
				};
			}
		});
	}
	
	//print output function
	//starts by making sure the output area is clear, takes the selected date, converts it to a string then splits it.
	//A new integer array is created and the string array is copied to the integer array while the strings are
	//being converted to strings. Then the employees on shift are cycled through and outputted onto the screen
	@FXML
    private void printOutput() 
    {
		
		listEmps.getItems().clear();
		
		//error checker; if the user hits view without entering a date an error will pop up 
		//reminding the user to select a date
		if (date.getValue() == null)
		{
			//creating the alert box
			Alert noDate;
			noDate = new Alert(AlertType.ERROR);

			// Set up the Alert text.
			noDate.setTitle("ERROR");
			noDate.setHeaderText("Please Select a Date");
			
			//showing the alert box
			noDate.showAndWait();
		}
		else
		{
			//converts the date value to a string array to allow grabbing of the month, day, year
			//then converts that string array into an integer array
			String [] stringArr = date.getValue().toString().split("-");
			int [] intArr = new int [3];
			for (int i = 0; i < 3;i++)
			{
				intArr[i]= Integer.parseInt(stringArr[i]);
			}
			
			//creating a local date out of the inputted date
			LocalDate lDate = LocalDate.of(intArr[0], intArr[1], intArr[2]);
			
			//checks if the day the user selects is a sunday
			//if it is a sunday, an error message will pop up
			if (lDate.getDayOfWeek() == DayOfWeek.SUNDAY)
			{
				//creating an alert box
				Alert sunday;
				sunday = new Alert(AlertType.ERROR);
	
				// Set up the Alert text.
				sunday.setTitle("ERROR");
				sunday.setHeaderText("Restaurant is Closed on Sundays");
				
				//showing the alert box
				sunday.showAndWait();
			}
			//checks if the day the user selects is a holiday
			//if it is a holiday, an error message will pop up
			else if(holidays.contains(lDate))
			{
				//creating an alert box
				Alert holiday;
				holiday = new Alert(AlertType.ERROR);
	
				// Set up the Alert text.
				holiday.setTitle("ERROR");
				holiday.setHeaderText("Restaurant is Closed For Holidays");
				
				//showing the alert box
				holiday.showAndWait();
			}
			//if the user selects a date that is not a sunday or holiday this part will execute
			else
			{
				//this checks to see if the selected date contains a schedule
				if (employees.Schedule_launcher.getSchedule(intArr[0], intArr[1], intArr[2]).getEmployee()!=null)
				{
					//adding all the employees on the selected schedule date to the output window
					for (int j = 0; j< employees.Schedule_launcher.getSchedule(intArr[0], intArr[1], intArr[2]).getEmployee().size(); j++)
					{
						listEmps.getItems().addAll(employees.Schedule_launcher.getSchedule(intArr[0], intArr[1], intArr[2]).getEmployee().get(j).toString());
					}
				}
				//this part executes if a user selects a day that is not a holiday, not a sunday, and does not contain
				// a schedule
				else
				{
					//Creating the alert box
					Alert noSchedule;
					noSchedule = new Alert(AlertType.ERROR);
		
					// Set up the Alert text.
					noSchedule.setTitle("ERROR");
					noSchedule.setHeaderText("No Schedule Under The Selected Date");
					
					//showing the alert box
					noSchedule.showAndWait();
				}
			}
    	}
		//resets the date input value to be blank
		date.setValue(null);
    }
	
	
}