package gui.employeesTab;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

//view employees tab controller class
public class ViewEmployeesTabController {
	
	//creating a variable to correlate with the variables in the fxml file
	@FXML
	private ListView<String> listEmps1;
	
	@FXML
	private Button show;
	
	@FXML
	private URL location;
	
	@FXML
	private ResourceBundle resources;
	
	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public ViewEmployeesTabController() {
	}
	
	/**
	 * This is a private method with a void return
	 * type, and is needed by the FXML loader object. In this instance,
	 * I have the employee list set to populate when the program runs
	 */
	@FXML
	private void initialize() 
	{	
		//populating the employee list
		employees.Employee_launcher.populateList();
		
		//populating the on screen list of employees
		for(int i =0; i< employees.Employee_launcher.getEmployees().size();i++)
		{
			listEmps1.getItems().addAll(employees.Employee_launcher.getEmployees().get(i).toString());
		}
	}
	
	//selectEmps functions
	//gives the user the option to click on a employee and see more personal information about the employee
	@FXML
	private void selectEmps()
	{
		//gets the selected employee and converts their id number into an integer
		String selectedEmp = listEmps1.getSelectionModel().getSelectedItem();
		int selectedEmpID = Integer.parseInt(selectedEmp.substring(4, 7));
		
		//making sure there is an employee selected
        if (selectedEmp != null) 
        {
        	//creating and displaying the alert box
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Selected Employee");
            alert.setHeaderText(null);
            alert.setContentText(employees.Employee_launcher.getEmp(selectedEmpID).personalToString());
            alert.showAndWait();
        }
	}
	

	

	
}