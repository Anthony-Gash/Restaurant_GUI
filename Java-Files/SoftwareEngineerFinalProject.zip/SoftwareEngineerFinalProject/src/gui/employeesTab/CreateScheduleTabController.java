package gui.employeesTab;

import employees.Employee;
import java.net.URL;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.util.Callback;

//view employees tab controller class
public class CreateScheduleTabController {
	
	//creating a variable to correlate with the variables in the fxml file
	@FXML
	private ListView<String> listEmps2;
	
	@FXML
	private ListView<String> selectedEmps;
	
	@FXML
	private DatePicker date1;
	
	@FXML
	private Button createButton;
	
	@FXML
	private Button removeButton;
	
	@FXML
	private Button selectButton;
	
	//creates a list of holidays to allow the system to correctly color certain dates
	List<LocalDate> holidays = new ArrayList<>();
	
	
	@FXML
	private URL location;
	
	@FXML
	private ResourceBundle resources;
	
	/**
	 * This is a public no-args constructor needed
	 * by the FXML loader object.
	 */
	public CreateScheduleTabController() {
	}
	
	/**
	 * This is a private method with a void return
	 * type, and is needed by the FXML loader object. In this instance, 
	 * I have the employee list set to populate when the program runs
	 */
	@FXML
	private void initialize() {	
		//populating the schedule list right from the beginning
		employees.Schedule_launcher.populateSched();
				
		//creating a list of holidays
		for (int i = 2000; i<2030;i++)
		{
			holidays.add(LocalDate.of(i, Month.JANUARY, 1));
			holidays.add(LocalDate.of(i, Month.JULY, 4));
			holidays.add(LocalDate.of(i, Month.DECEMBER, 25));
		}
		
		//populates the employee list
		for(int i =0; i< employees.Employee_launcher.getEmployees().size();i++)
		{
			listEmps2.getItems().addAll(employees.Employee_launcher.getEmployees().get(i).toString());
		} 
		//creating a cell factory to allow the calendar days to be set to a different color based on certain
		// parameters
		date1.setDayCellFactory(new Callback<DatePicker, DateCell>() {
			@Override
			public DateCell call(DatePicker param) {
				return new DateCell(){
					@Override
					public void updateItem(LocalDate item, boolean empty) {
						super.updateItem(item, empty);

						if (!empty && item != null) {
							for (int i =1; i<employees.Schedule_launcher.schedules.size(); i++)
							{
								//if statement to set scheduled days to yellow
								if((employees.Schedule_launcher.schedules.get(i).getDay() == (item.getDayOfMonth())) &&
								(employees.Schedule_launcher.schedules.get(i).getMonth() == (item.getMonthValue())) &&
								(employees.Schedule_launcher.schedules.get(i).getYear() == (item.getYear())))
								{
									this.setStyle("-fx-background-color: #e8e830");
								}
							}
							//sets the day to blue if its a holiday
							if(holidays.contains(item))
							{
								this.setStyle("-fx-background-color: #4db8ff");

							}
							//sets the day to red if its a sunday	
							if (item.getDayOfWeek() == DayOfWeek.SUNDAY)
							{
								this.setStyle("-fx-background-color: #ff4d4d");
							}
						}
					}
				};
			}
		});
	}
	
	//select method
	// allows the user to select employees from a list to work
	@FXML
    private void select() 
	{
        String selected = listEmps2.getSelectionModel().getSelectedItem();
        
        //removes that employee from the total list
        listEmps2.getItems().remove(selected);
        
        //adds that employee to the selected list
        selectedEmps.getItems().addAll(selected);
    }
	
	//remove method
	//allows the user to remove employees from the selected list
	//in the event they added the wrong employee to the selected list
	@FXML
	private void remove()
	{
		String selected = selectedEmps.getSelectionModel().getSelectedItem();
		
		//removes the employee form the selected list
        selectedEmps.getItems().remove(selected);
        
        //adds that employee back to the total list
        listEmps2.getItems().addAll(selected);
	}
	
	//create function
	//this function creates the schedule that user selected.
	@FXML
	private void create()
	{
		//creates a list of selected employees
		List<Employee> selectedEmployees = new ArrayList<Employee> ();
		
		//adds the employees from a string array, converts them to employee objects and
		//adds the employee objects to the employee list
		for (int j = 0; j<selectedEmps.getItems().size();j++)
		{
			String [] strings = selectedEmps.getItems().get(j).split(" ");
			selectedEmployees.add(employees.Employee_launcher.getEmp(Integer.parseInt(strings[1])));
		}
		
		//checks first to make sure that a date is selected
		if (date1.getValue() == null)
		{
			//creating the alert box
			Alert noSchedule;
			noSchedule = new Alert(AlertType.ERROR);

			// Set up the Alert text.
			noSchedule.setTitle("ERROR");
			noSchedule.setHeaderText("Please Select a Date");
			
			//showing the alert box
			noSchedule.showAndWait();
		}
		//checks to make sure the user has selected employees for the schedule
		else if(selectedEmployees.size() == 0)
		{
			//creating the alert box
			Alert noEmps;
			noEmps = new Alert(AlertType.ERROR);

			// Set up the Alert text.
			noEmps.setTitle("ERROR");
			noEmps.setHeaderText("Please Select Desired Employee(s)");
			
			//showing the alert box
			noEmps.showAndWait();		
		}
		//this code runs if there are no errors (empty fields)
		else
		{
			//converts the date to a string array and adds it to an integer array
			String [] stringArr = date1.getValue().toString().split("-");
			int [] intArr = new int [3];
			for (int i = 0; i < 3;i++)
			{
				intArr[i]= Integer.parseInt(stringArr[i]);
			}
			
			//creates a local date 
			//Might seem unnecessary but is needed to check if they are trying to create a schedule
			//on a sunday
			LocalDate lDate = LocalDate.of(intArr[0], intArr[1], intArr[2]);			
			
			
			//Next needs to make sure that the day of week selected is not sunday as it is closed
			if (lDate.getDayOfWeek() == DayOfWeek.SUNDAY)
			{
				//creating the alert box
				Alert sunday;
				sunday = new Alert(AlertType.ERROR);
	
				// Set up the Alert text.
				sunday.setTitle("ERROR");
				sunday.setHeaderText("Restaurant is Closed on Sundays");
				
				//showing the alert box
				sunday.showAndWait();
			}
			//Checks to make sure a holiday is not selected
			else if (holidays.contains(lDate))
			{
				//creating the alert box
				Alert holiday;
				holiday = new Alert(AlertType.ERROR);
	
				// Set up the Alert text.
				holiday.setTitle("ERROR");
				holiday.setHeaderText("Restaurant is Closed For Holidays");
				
				//showing the alert box
				holiday.showAndWait();
			}
			//if statement to let the user know there is already a schedule for the selected date
			//the user is given the option to overwrite the current schedule or go back
			else if(employees.Schedule_launcher.getSchedule(intArr[0], intArr[1], intArr[2]).getEmployee()!=null)
			{
				//creating the alert box
				Alert overWriteSchedule;
				overWriteSchedule = new Alert(AlertType.CONFIRMATION);
	
				// Set up the Alert text.
				overWriteSchedule.setTitle("ERROR");
				overWriteSchedule.setHeaderText("Restaurant Already Has a Schedule For This Date");
				overWriteSchedule.setContentText("By Pressing \"OK\" you can overwrite the current schedule.\n"+
													"Otherwise press cancel");
				
				
				//showing the alert box
				Optional<ButtonType> overwriteButton = overWriteSchedule.showAndWait();
				if (overwriteButton.get() == ButtonType.OK)
				{
					//creates the schedule from the integer array(date) and employee list
					employees.Schedule_launcher.addSchedule(intArr[0], intArr[1], intArr[2], selectedEmployees);
					
					//resets all the input fields
					date1.setValue(null);
					listEmps2.getItems().addAll(selectedEmps.getItems());
					selectedEmps.getItems().clear();
				}
			}
			//this will execute if the selected date is not a holiday, sunday, or previously scheduled day
			else
			{
				//creates the schedule from the integer array(date) and employee list
				employees.Schedule_launcher.addSchedule(intArr[0], intArr[1], intArr[2], selectedEmployees);
				
				//resets all the input fields
				date1.setValue(null);
				listEmps2.getItems().addAll(selectedEmps.getItems());
				selectedEmps.getItems().clear();
			}
		}
		
	}
	

	
}