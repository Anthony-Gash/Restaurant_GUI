package employees;
//The employee class
public class Employee
{
	//basic information for each employee
	int empID;
	String empFName;
	String empLName;
	String empJob;
	String address;
	String email;
	String time;
	
	//employee constructor
	public Employee(int id, String fName, String lName, String job)
    {
		empID = id;
		empFName = fName;
		empLName = lName;
		empJob = job;
    }
	
	public Employee(int id, String fName, String lName, String job, String ad, String em)
    {
		empID = id;
		empFName = fName;
		empLName = lName;
		empJob = job;
		address = ad;
		email = em;
    }
	
	//get employee id function, returns employee id
	public int getEmpID()
	{
		return empID;
	}
	
	//get employee first name function, returns the first name
	public String getEmpFName()
	{
		return empFName;
	}
	
	//get employee last name function, returns the last name
	public String getEmpLName()
	{
		return empLName;
	}
	
	//get employee job function, returns the job
	public String getEmpJob()
	{
		return empJob;
	}
	
	//get employee address function, returns the address
	public String getEmpAddress()
	{
		return address;
	}
		
	//get employee email function, returns the email
	public String getEmpEmail()
	{
		return email;
	}
	
	//set employee id function, takes in a new id and sets the employee id to that
	public void setEmpID(int id)
	{
		empID = id;
	}
	
	//set employee first name function, takes in a new first name and sets the employee first name to that
	public void setEmpFName(String fName)
	{
		empFName = fName;
	}
	
	//set employee last name function, takes in a new last name and sets the employee last name to that
	public void setEmpLName(String lName)
	{
		empLName = lName;
	}
	
	//set employee job function, takes in a new job and sets the employee job to that
	public void setEmpJob(String job)
	{
		empJob = job;
	}
	
	//set employee address function, takes in a new address and sets the employee address to that
	public void setEmpAddress(String add)
	{
		address = add;
	}
		
	//set employee email function, takes in a new email and sets the employee email to that
	public void setEmpEmail(String em)
	{
		email = em;
	}
	
	//to string function that allows all the basic employee information to be outputted
	public String toString()
	{
		return String.format("ID: %d \n" +
				"Name: %s %s\n" +
				"Job: %s", empID, empFName, empLName, empJob);
	}
	
	//to string function that allows all the personal employee information to be outputted
		public String personalToString()
		{
			return String.format("ID: %d \n" +
					"Name: %s %s\n" +
					"Job: %s \n"+
					"Email: %s \n"+
					"Address: %s", empID, empFName, empLName, empJob,email,address);
		}
	
	
}