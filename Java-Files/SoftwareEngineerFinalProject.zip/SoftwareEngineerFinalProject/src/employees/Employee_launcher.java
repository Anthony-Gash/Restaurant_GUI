package employees;


import java.util.ArrayList;
import java.util.List;

//Employee launcher class
public class Employee_launcher
{
	//creates a global list of employees called empList
	public static List<Employee> empList = new ArrayList<Employee> ();
	
	//populate list function
	//creates 20 "dummy" employees and adds them to the global employee list
	public static void populateList()
	{
		//adds all the employees to the list
		empList.add(new Employee(123, "Bill", "Nye", "Chef", "123 Main Street, Oakwood Heights, Cityville, ABC123",
				"nye.bill@deliciousrestaurant.com"));
		empList.add(new Employee(124, "Joe", "Smith", "Waiter", "456 Elm Avenue, Willow Springs, Townburg, XYZ456",
				"smith.joe@deliciousrestaurant.com"));
		empList.add(new Employee(125, "Nate", "Gordon", "Manager", "789 Pine Lane, Maple Grove, Villageton, DEF789",
				"gordon.nate@deliciousrestaurant.com"));
		empList.add(new Employee(126, "Luke", "Hoffman", "Manager", "1010 Cedar Road, Birchwood Park, Hamletville, GHI101",
				"hoffman.luke@deliciousrestaurant.com"));
		empList.add(new Employee(127, "Anthony", "Gash", "Manager", "1313 Oakwood Drive, Aspen Meadows, Villatown, JKL131",
				"gash.anthony@deliciousrestaurant.com"));
		empList.add(new Employee(128, "Jake", "Daniels", "Waiter", "1515 Birch Street, Pinecrest Estates, Boroughville, MNO151",
				"daniels.jake@deliciousrestaurant.com"));
		empList.add(new Employee(129, "Mike", "Tyson", "Chef", "1717 Maple Court, Cedarwood Hills, Township, PQR171",
				"tyson.mike@deliciousrestaurant.com"));
		empList.add(new Employee(130, "Brandon", "Katz", "Host", "1919 Willow Lane, Oakdale Farms, Villaville, STU191",
				"katz.brandon@deliciousrestaurant.com"));
		empList.add(new Employee(131, "Emily", "Hart", "Waitress", "2121 Pinecrest Avenue, Cedar Ridge, Cityburg, VWX212",
				"hart.emily@deliciousrestaurant.com"));
		empList.add(new Employee(132, "John", "Wick", "Busboy", "2323 Cedar Lane, Elmwood Manor, Townville, YZA232",
				"wick.john@deliciousrestaurant.com"));
		empList.add(new Employee(133, "Liam", "Johnson", "Busboy", "2525 Elm Street, Birchwood Heights, Villaville, BCD252",
				"johnson.liam@deliciousrestaurant.com"));
		empList.add(new Employee(134, "Ethan", "Martinez", "Cook", "2727 Willow Road, Maple Ridge, Hamletburg, CDE272",
				"martinez.ethan@deliciousrestaurant.com"));
		empList.add(new Employee(135, "Oliver", "Garcia", "Cook", "2929 Birch Avenue, Oakdale Park, Boroughburg, DEF292",
				"garcia.oliver@deliciousrestaurant.com"));
		empList.add(new Employee(136, "Mason", "Anderson", "Waiter", "3131 Maple Drive, Pine Grove, Townville, EFG313",
				"anderson.mason@deliciousrestaurant.com"));
		empList.add(new Employee(137, "Noah", "Hernandez", "Waiter", "3333 Cedar Lane, Willowcrest, Citytown, FGH333",
				"hernandez.noah@deliciousrestaurant.com"));
		empList.add(new Employee(138, "Emma", "Taylor", "Waitress", "3535 Oakwood Avenue, Birchwood Estates, Villatown, GHI353",
				"taylor.emma@deliciousrestaurant.com"));
		empList.add(new Employee(139, "Olivia", "Brown", "Waitress", "3737 Elm Court, Cedarwood Park, Township, HIJ373",
				"brown.olivia@deliciousrestaurant.com"));
		empList.add(new Employee(140, "Ava", "Davis", "Hostess", "3939 Pine Road, Aspen Meadows, Boroughburg, IJK393",
				"davis.ava@deliciousrestaurant.com"));
		empList.add(new Employee(141, "Isabella", "Wick", "Hostess", "4141 Birch Lane, Maplewood Hills, Villaville, JKL414",
				"wick.isabella@deliciousrestaurant.com"));
		empList.add(new Employee(142, "Sophia", "Rodriguez", "Waitress", "4343 Willow Street, Oakwood Heights, Hamletville, KLM434",
				"rodriguez.sophia@deliciousrestaurant.com"));

	}
	
	//get employees function, returns all the employees on the global list
	public static  List<Employee> getEmployees()
	{
		return empList;
	}
	
	//get employee function, returns an employee specified by their id number
	public static Employee getEmp(int iD)
	{
		Employee emp = null;
		for (int i = 0; i<empList.size();i++)
		{
			if (empList.get(i).getEmpID() == iD)
			{
				emp = empList.get(i);
			}
		}
		return emp;
	}
}