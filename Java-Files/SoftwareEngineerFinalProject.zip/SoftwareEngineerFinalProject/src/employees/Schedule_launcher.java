package employees;


import java.util.ArrayList;
import java.util.List;


//schedule launcher class
public class Schedule_launcher
{
	//creates a global list of schedules
	public static List<Schedule> schedules = new ArrayList<Schedule> ();
	
	//populate schedule function
	//populates the employee list, creates two "dummy" shifts for Jan 1, 2002 and Feb 3 2010
	//adds 5 employees to each shift, then adds the shifts to the schedules list
	public static void populateSched()
	{
		
		//creating shift1
		List<Employee> empShift1 = new ArrayList<Employee> ();
		//adds 5 employees to the shift
		for (int i =0; i<=4;i++)
		{
			empShift1.add(Employee_launcher.getEmployees().get(i));
		}
		
		//creating shift2
		List<Employee> empShift2 = new ArrayList<Employee> ();
		//adds 5 employees to the shift
		for (int i =5; i<=9;i++)
		{
			empShift2.add(Employee_launcher.getEmployees().get(i));
		}

		
		//creating shift 3
		List<Employee> empShift3 = new ArrayList<Employee> ();
		//adds 5 employees to the shift
		for (int i =10; i<=14;i++)
		{
			empShift3.add(Employee_launcher.getEmployees().get(i));
		}

		//creating shift 4
		List<Employee> empShift4 = new ArrayList<Employee> ();
		//adds 5 employees to the shift
		for (int i =15; i<=19;i++)
		{
			empShift4.add(Employee_launcher.getEmployees().get(i));
		}
		
		//creates a schedule of the shifts
		Schedule sch0 =  new Schedule(0, 0, 0, null);
		Schedule sch1 =  new Schedule(01,01,2002, empShift1);
		Schedule sch2 =  new Schedule(02,03,2010, empShift2);
		Schedule sch3 =  new Schedule(04,10,2024, empShift3);
		Schedule sch4 =  new Schedule(03,21,2024, empShift4);
		
		//adds the schedules to the schedule list
		schedules.add(sch0);
		schedules.add(sch1);
		schedules.add(sch2);
		schedules.add(sch3);
		schedules.add(sch4);
	}
	
	//get schedule function
	//when called, populates the schedules, finds the desired schedule, and returns in
	public static  Schedule getSchedule(int year, int month, int day)
	{
		int sch = 0;
		for (int i =0; i < schedules.size(); i++)
		{
			if((schedules.get(i).getDay() == day) && (schedules.get(i).getMonth() == month) && (schedules.get(i).getYear() == year))
			{
				sch=i;
			}
			
		}
		return schedules.get(sch);
	} 
	
	//add schedule function
	// take in parameters for a new schedule then adds it to the schedule list
	public static void addSchedule(int year, int month, int day, List<Employee> e)
	{
		schedules.add(new Schedule(month, day, year, e));
	}
}