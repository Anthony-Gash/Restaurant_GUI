package employees;

import java.util.List;

//schedule class
public class Schedule
{
	//all the basic information needed for a schedule
	int month;
	int day;
	int year;
	List<Employee> emp; 
	
	//schedule constructor, takes in dates in month, day, year and then the list of employees
	public Schedule(int m, int d, int y, List<Employee> e)
    {
		month = m;
		day = d;
		year = y;
		emp = e;
    }
	
	//second schedule constructor. Only purpose is to house the empty schedule item.
	//helps check if the user didn't input a date in the view schedule tab
	public Schedule(int m, int d)
    {
		month = m;
		day = d;
    }
	
	
	//get month function, returns the month
	public int getMonth()
	{
		return month;
	}
	
	//get day function, returns the day
	public int getDay()
	{
		return day;
	}
	
	//get year function, returns the year
	public int getYear()
	{
		return year;
	}
	
	//get employee function, returns the employees working that schedule
	public List<Employee> getEmployee()
	{
		return emp;
	}
	
	//set month function, takes in a new month and sets the month to the new one
	public void setMonth(int m)
	{
		month = m;
	}
	
	//set day function, takes in a new day and sets the day to the new one
	public void setDay(int d)
	{
		day = d;
	}
	
	//set year function, takes in a new year and sets the year to the new one
	public void setYear(int y)
	{
		year = y;
	}
	
	//set employee function, takes in a new list of employees and sets the employees to the new one
	public void setEmps(List<Employee> e)
	{
		emp = e;
	}
	
	
}