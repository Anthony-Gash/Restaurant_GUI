package data;

//import java.sql.CallableStatement;
//import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

/**
 * This class contains prepared SQL statements for handling a table
 * of restaurant order data and also contains associated methods.
 * 
 * @author Luke Hoffman (gmaj9)
 */
public class OrderStatements extends StatementCollection {
	// Fields

	// TODO: Build this string programmatically via a TableDefinition object.
	// String defining add order statement. Used below in initAddOrder() to initialize a PreparedStatement.
	private final String addOrderStmntStr = "INSERT INTO orders(" + 
			"orderID, customerName, tableNumber, orderNotes, " + 
			"submissionTime, status, menuItems, isUpdated, updateTimes) " + 
			"VALUES(?, ?, ?, ?, " + 
			"?, ?, ?, ?, ?)";

	/* PreparedStatement for adding orders.
	 * Initialized below in initStatements() by a call to initAddOrder().
	 */
	private PreparedStatement addOrder;
	private ResultSet addOrderResult;

	// Constructors

	/**
	 * Non-empty constructor for OrderStatements.
	 * 
	 * // TODO: probably don't need the following 3 lines or it's not a helpful way to do it.
	 * // Sets the Connection to use, which is called theConn in OrderStatments's superclass, as the parameter con.
	 * 
	 * // @param con - The Connection object for the database to use.
	 */
	public OrderStatements(/*Connection con*/) {
		
		// TODO: probably don't need the following line or it's not a helpful way to do it.
		//theConn = con; // Set the connection to the connection specified (no deep copy; using directly).
		
		// Call the superclass's constructor (which calls the overridden initStatements() method).
		super();
	}

	@Override
	public void initStatements() throws SQLException {

		// Initialize all the statements to what they should be
		initAddOrder();

		// Can add more PreparedStatements down here.

	}

	/**
	 * Initializes the addOrder PreparedStatement.
	 * 
	 * //@return an initialized PreparedStatement
	 * @throws SQLException
	 */
	private void initAddOrder() throws SQLException {
		// Return generated keys (AKA order ID numbers).
		addOrder = con.prepareStatement(addOrderStmntStr, Statement.RETURN_GENERATED_KEYS);
		addOrderResult = null;
	}

	/**
	 * Sets values to be used in the addOrder (order submission) statement.
	 * 
	 * See the database and/or TableDefStrings.java for the orders table creation statement.
	 * 
	 * @param id - An integer containing the order's ID number (should be unique and not null - it's the primary key) 
	 * @param custName - A String containing the name of the customer associated with the order (not null)
	 * @param tableNum - An integer indicating the order's destination table (not null)
	 * @param notes - A String containing any notes about the order (can be null)
	 * @param submissTime - A String representing the order submission timestamp (not null)
	 * @param status - A String representing the order's lifecycle status (not null)
	 * @param menuItems - A String listing all associated/ordered menu items (can be null)
	 * @param isUpdated - A String indicating if the order record has been updated (not null)
	 * @param updateTimes - A String indicating each timestamp at which the record has been updated (not null)
	 * @throws SQLException if/when things go wrong
	 */
	public void setValuesAddOrder(int id, String custName, int tableNum,
			String notes, String submissTime, String status,
			String menuItems, int isUpdated, String updateTimes) throws SQLException {
		// Clear existing paramter values, if any
		//if (addOrder != null) {
		//	addOrder.clearParameters();
		//}
		
		// Set parameters to match input values
		
		// If id is 0, that means the calling code has specified the ID number to set (probably won't work though).
		if (id != 0) {
			addOrder.setInt(1, id);
		}
		// If id is 0, that means the praimary key value should be null so the order ID number continues to autoincrement.
		else {
			addOrder.setNull(1, Types.INTEGER);
		}
		
		addOrder.setString(2, custName);
		addOrder.setInt(3, tableNum);
		addOrder.setString(4, notes);
		addOrder.setString(5, submissTime);
		addOrder.setString(6, status);
		addOrder.setString(7, menuItems);
		addOrder.setInt(8, isUpdated);
		addOrder.setString(9, updateTimes);
	}

	/**
	 * Executes the addOrder PreparedStatement and returns its ResultSet.
	 * This will probably throw a SQLException about violating a unique
	 * constraint, since it keeps the previous values set by setValuesAddOrder().
	 * 
	 * @throws SQLException
	 */
	public void executeAddOrder() throws SQLException {
		// Execute the query and set addOrderResult to be its ResultSet of generated keys.
		addOrderResult = addOrder.executeQuery();
		addOrderResult = addOrder.getGeneratedKeys();
	}

	/**
	 * Executes the addOrder PreparedStatement and returns its ResultSet.
	 * 
	 * Will throw a SQLException if anything goes wrong, or if any of the constraints for inserting
	 * values are violated.
	 * 
	 * @param id - An integer containing the order's ID number (should be unique and not null - it's the primary key) 
	 * @param custName - A String containing the name of the customer associated with the order (not null)
	 * @param tableNum - An integer indicating the order's destination table (not null)
	 * @param notes - A String containing any notes about the order (can be null)
	 * @param submissTime - A String representing the order submission timestamp (not null)
	 * @param status - A String representing the order's lifecycle status (not null)
	 * @param menuItems - A String listing all associated/ordered menu items (can be null)
	 * @param isUpdated - A String indicating if the order record has been updated (not null)
	 * @param updateTimes - A String indicating each timestamp at which the record has been updated (not null)
	 * //@return The ResultSet coming from the execution of the addOrder statement.
	 * @throws SQLException
	 */
	public void executeAddOrder(int id, String custName, int tableNum,
			String notes, String submissTime, String status,
			String menuItems, int isUpdated, String updateTimes) throws SQLException {

		// Set the details of the order that will be added.
		setValuesAddOrder(id, custName, tableNum,
				notes, submissTime, status,
				menuItems, isUpdated, updateTimes);

		// Execute the statement and store its ResultSet of generated keys.
		addOrder.executeUpdate();
		addOrderResult = addOrder.getGeneratedKeys();
	}
	
	/**
	 * Gets the latest order ID number (auto-generated primary key) from thew database.
	 * 
	 * @return The lastest order ID number (an auto-generated primary key) from the database.
	 * @throws SQLException
	 */
	public int getLatestOrderID() throws SQLException {
		int key = 0; // To store the key.
		
		// Get the latest key.
		if (addOrderResult.next()) {
			key = addOrderResult.getInt(1);
		}
		
		// Return the key.
		return key;
	}
}