package data;

/**
 * Class representing a database table definition.
 * 
 * WARNING! Doesn't yet support:
 * Foreign keys,
 * Multiple primary keys,
 * Ensuring that primary keys are not null,
 * Ensuring that only one primary key exists when autoincrement is used,
 * And various other subtleties I haven't though of yet.
 * 
 * TODO: equals, toString, copy constructor, (mutators, or remove empty constructor?)
 * 
 * @author Luke Hoffman (gmaj9)
 */
public class TableDefinition {
	String tableName;

	String[] columnNames;

	String[] columnTypes;

	boolean[] isColumnNotNull;

	boolean[] isColumnPrimaryKey;

	boolean[] shouldColumnAutoIncrement;

	boolean[] isColumnUnique;

	String tableDefStr;

	/**
	 * Empty constructor.
	 */
	public TableDefinition() {
		tableName = "";
		columnNames = null;
		columnTypes = null;
		isColumnNotNull = null;
		isColumnPrimaryKey = null;
		shouldColumnAutoIncrement = null;
		isColumnUnique = null;

		tableDefStr = null;
	}

	/**
	 * Non-empty constructor.
	 * 
	 * @param name - String containing table's name
	 * @param colNames - String array containing names of columns
	 * @param colTypes - String array containing column types
	 * @param isColNN - boolean array indicating if column is not null
	 * @param isColPK - boolean array indicating if column is primary key
	 * @param shldColAI - boolean array indicating if column should auto-increment
	 * @param isColUQ - boolean array indicating if column is unique
	 */
	public TableDefinition(String name, String[] colNames, String[] colTypes, boolean[] isColNN,
			boolean[] isColPK, boolean[] shldColAI, boolean[] isColUQ) {
		tableName = name;
		columnNames = colNames;
		columnTypes = colTypes;
		isColumnNotNull = isColNN;
		isColumnPrimaryKey = isColPK;
		shouldColumnAutoIncrement = shldColAI;
		isColumnUnique = isColUQ;

		// Create SQLite table creation string.
		tableDefStr = buildTableDefStr();
	}

	/**
	 * Gets the table's name.
	 * @return a String defining the table's name.
	 */
	public String getTableName() {
		return tableName;
	}

	/**
	 * Gets the columns's names.
	 * @return a String array containing the columns's names.
	 */
	public String[] getColNames() {
		String[] names = null;

		for (int i = 0; i < columnNames.length; i++) {
			names[i] = columnNames[i];
		}

		return names;
	}

	/**
	 * Gets the columns's types.
	 * @return a String array containing the columns's types.
	 */
	public String[] getColTypes() {
		String[] types = null;

		for (int i = 0; i < columnTypes.length; i++) {
			types[i] = columnTypes[i];
		}

		return types;
	}

	/**
	 * Gets whether the columns are not null or not.
	 * @return a boolean array indicating whether the columns are not null or not.
	 */
	public boolean[] getIsColNN() {
		boolean[] nn = null;

		for (int i = 0; i < isColumnNotNull.length; i++) {
			nn[i] = isColumnNotNull[i];
		}

		return nn;
	}

	/**
	 * Gets whether the columns are primary keys or not.
	 * @return a boolean array indicating whether the columns are primary keys or not.
	 */
	public boolean[] getIsColPK() {
		boolean[] pk = null;

		for (int i = 0; i < isColumnPrimaryKey.length; i++) {
			pk[i] = isColumnPrimaryKey[i];
		}

		return pk;
	}

	/**
	 * Gets whether the columns should auto-increment or not.
	 * @return a boolean arrya indicating whether the columns auto-increment.
	 */
	public boolean[] getShldColAI() {
		boolean[] ai = null;

		for (int i = 0; i < shouldColumnAutoIncrement.length; i++) {
			ai[i] = isColumnPrimaryKey[i];
		}

		return ai;
	}

	/**
	 * Gets whether the columns are unique or not.
	 * @return a boolean array indicating whether or not the columns are unique.
	 */
	public boolean[] getIsColUQ() {
		boolean[] uq = null;

		for (int i = 0; i < isColumnUnique.length; i++) {
			uq[i] = isColumnUnique[i];
		}

		return uq;
	}

	/**
	 * Builds a string that defines a SQLite table creation statement.
	 * @return
	 */
	private String buildTableDefStr() {
		// Start with the create table text
		String tableDef = "CREATE TABLE IF NOT EXISTS ";
		String endingLine = null; // This defines the ending line (where primary keys are defined)

		// Build up the table name
		tableDef += "\"" + tableName + "\" (\n";

		// Build each column declaration
		for (int i = 0; i < columnNames.length; i++) {
			// Build up the column's name and type
			tableDef += "\"" + columnNames[i] + "\"" + "\t" + columnTypes[i];

			// Build up if the column is not null
			if (isColumnNotNull[i]) {
				tableDef += " NOT NULL";
			}

			// Build up if the column is unique
			if (isColumnUnique[i]) {
				tableDef += " UNIQUE";
			}

			// Toss in the comma and newline at the end of the column declaration
			tableDef += ",\n";

			// Account for if the column is a primary key and/or should autoincrement
			if (isColumnPrimaryKey[i]) {
				if (endingLine == null) {
					endingLine = "PRIMARY KEY(";
				}

				endingLine += "\"" + columnNames[i] + "\"";

				if (shouldColumnAutoIncrement[i]) {
					endingLine += " AUTOINCREMENT";
				}

				endingLine += ")\n);";
			}
		}

		// Add on the ending line of the create statement
		tableDef += endingLine;

		return tableDef; // Return it at last!
	}

	/**
	 * Gets the table's SQLite create statement String.
	 * @return a String defining the table's SQLite create statement.
	 */
	public String getTableDefStr() {
		return tableDefStr;
	}
}