package data;

import java.sql.Connection;
//import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * This class is to be extended and represents a collection of
 * reusable SQLite statements.
 * 
 * TODO: equals, toString, copy constructor, anything else needed
 * 
 * @author Luke Hoffman (gmaj9)
 */
public abstract class StatementCollection {
	// Fields
	//TODO: Check if public is good here
	public Connection con; // Connection to a database that the statements will be used with

	// Constructors

	public StatementCollection() {
		con = ConnectDB.conn; // Set the connection to ConnectDB.conn (no deep copy; used directly)

		// Try initializing the statments; otherwise, if there's an exception, ouput its stack trace
		try {
			
			// Initialize the statements that will be usable.
			initStatements();
			
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block (works for now though)
			e.printStackTrace();
		}
	}

	// Methods

	/**
	 * Abstract method that should be used to initialize reusable statements.
	 * 
	 * @throws SQLException 
	 */
	public abstract void initStatements() throws SQLException;

}