package data;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
//import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.sql.Statement;

/**
 * This class provides functions for connecting
 * to the application's SQLite database.
 * 
 * @author Luke Hoffman (gmaj9)
 */
public class ConnectDB {

	// Fields

	// Get the host operating system's file separator.
	public static String fileSep = File.separator;

	// Stores the connection to the database.
	//TODO: check if public scope is good here
	public static Connection conn = null;

	// Statement to use with DB.
	private static Statement stmnt;

	// Database location.
	private static String url = "jdbc:sqlite:" + 
			"src" + fileSep + "data" + fileSep + "restaurantDB.db";
	
	private static TableDefinitionContainer TableDefContainer;

	public static OrderStatements orderStmnts;

	//private static String url = "jdbc:sqlite:" + System.getProperty("user.dir") + 
	//		fileSep + "data" + fileSep + "restaurantDB.db";

	// Methods

	/**
	 * This function connects to the database.
	 * 
	 * Any SQLException is printed to the console.
	 */
	public static void connect() {
		
		// Try establishing a connection to the DB.
		try {

			// Try initializing the database driver class (so it can connect).
			try {
				Class.forName("org.sqlite.JDBC");
				
			} catch (ClassNotFoundException e) {
				
				// Print trace if anything goes badly.
				e.printStackTrace();
			}

			// Set up the connection.
			conn = DriverManager.getConnection(url);

			// Set up the Statement.
			stmnt = conn.createStatement();

			// Output that the connection has been established.
			System.out.println("Connection to SQLite established.");

		} catch (SQLException e) {

			// Print trace if anything goes badly.
			e.printStackTrace();;
		}

	} // End of connect()

	/**
	 * Disconnects/closes the database.
	 * 
	 * Any SQLException is printed to the console.
	 */
	public static void disconnect() {

		// Try closing the connection if it isn't null.
		try {
			if (conn != null) {
				conn.close();
			}

		} catch (SQLException e) {

			// Print trace if anything goes badly.
			e.printStackTrace();
		}

	} // End of disconnect()

	/**
	 * Sets the URL of the database. (Perhaps an unneeded method?)
	 * 
	 * @param newUrl - A String specifying the database URL to set.
	 */
	public static void setUrl(String newUrl) {
		url = newUrl;
	} // End of setURL()

	/**
	 * This is just a function to execeute a SQLite statement contained in a String.
	 * 
	 * @param query SQLite statement.
	 * @return boolean indicating if statement was successful in executing.
	 * @throws SQLException if anything goes wrong.
	 */
	public static boolean executeStatement(String query) throws SQLException {
		return stmnt.execute(query);
	} // End of createTable()

	/**
	 * Initialize the database tables (AKA create them if they don't already exist).
	 * @throws SQLException
	 */
	public static void initializeDB() throws SQLException {
		// Initialize a TableDefinitionContainer object (which stores definitions for each database table that should exist)
		TableDefContainer = new TableDefinitionContainer();
		
		// Create the orders table
		executeStatement(TableDefContainer.getOrdersTableDef().getTableDefStr());
		
		// More of the same sort of table-creating activities should be carried out here:
		//createTable(TableDefinitionContainer.etcTableDef.getTableDefStr());
		
		// Initialize the prepared statements sets for each table
		initializeStatements();
		
	}
	
	/**
	 * Initialize the objects that manage statements for each table in the database.
	 * @throws SQLException
	 */
	public static void initializeStatements() throws SQLException {
		// Initialize an OrderStatements object.
		orderStmnts = new OrderStatements();
		
		// Put more StatementCollection object init statements down here!
	}

} // End of class ConnectDB