package data;

/**
 * TableStrings stores static Strings that
 * define SQLite table creation statements.
 * 
 * TODO: equals, toString, copy constructor, anything else needed
 * 
 * @author Luke Hoffman (gmaj9)
 */
public class TableDefinitionContainer {
	// Fields
	
	// *** Fields for defining Orders table ***
	private final String ordersTableName = "orders";
	private final String[] ordersColNames = {"orderID", "customerName", "tableNumber", "orderNotes", "submissionTime", "status", "menuItems", "isUpdated", "updateTimes"};
	private final String[] ordersColTypes = {"INTEGER", "TEXT", "INTEGER", "TEXT", "TEXT", "TEXT", "TEXT", "INTEGER", "TEXT"};
	private final boolean[] ordersColIsNotNull = {true, true, true, false, true, true, false, true, true};
	private final boolean[] ordersColIsPrimaryKey = {true, false, false, false, false, false, false, false, false};
	private final boolean[] ordersColShouldAutoIncrement = {true, false, false, false, false, false, false, false, false};
	private final boolean[] ordersColIsUnique = {true, false, false, false, false, false, false, false, false};
	
	private TableDefinition ordersTableDef; // TableDefinition object for building SQLite table creation statement
	// *** End of fields for defining Orders table ***
	
	// Constructors
	// TODO finish any needed constructor(s)
	public TableDefinitionContainer() {
		// Pass information to ordersTableDef to create an orders table creation statement inside of it
		ordersTableDef = new TableDefinition(ordersTableName, ordersColNames, ordersColTypes,
				ordersColIsNotNull, ordersColIsPrimaryKey, ordersColShouldAutoIncrement, ordersColIsUnique);
	}
	
	// Methods
	
	/**
	 * Gets orders table definition object.
	 * @return the orders TableDefinition object
	 */
	public TableDefinition getOrdersTableDef() {
		return ordersTableDef;
	}
	
	
}