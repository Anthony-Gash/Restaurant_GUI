package data;

/**
 * Class to test the TableDefinition class's stringBuilder() method.
 * 
 * @author Luke Hoffman (gmaj9)
 */
public class TableDefStringBuilderTest {
	public static void main(String[] args) {
		// Create a table definition container
		TableDefinitionContainer testTDefCont = new TableDefinitionContainer();
		
		// Print String returned by getOrdersTableDef() to see if the table createion statement was built correctly
		System.out.println(testTDefCont.getOrdersTableDef().getTableDefStr());
	}
}