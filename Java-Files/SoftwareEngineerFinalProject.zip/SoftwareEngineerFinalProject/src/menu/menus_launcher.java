package menu;

import java.util.ArrayList;
import java.util.List;

//menus launcher class
public class menus_launcher
{
	//creates 4 lists
	//a list of all the menus
	public static List<menus> allMenus = new ArrayList<menus> ();
	//a list of all items under the breakfast menu
	public static List<menuItems> breakfastMenuItems = new ArrayList<menuItems>();
	
	//a list of all items under the lunch menu
	public static List<menuItems> lunchMenuItems = new ArrayList<menuItems>();
	
	//a list of all items under the dinner menu
	public static List<menuItems> dinnerMenuItems = new ArrayList<menuItems>();

	//populate menus function
	//sorts all the starting menu items into their respective menus
	//then creates the 4 basic menus and adds them to all menus list
	public static void populateMenus()
	{
		//cycling through each menu item and adding it to its respective menu
		for (int i = 0; i<menu.menuItem_launcher.allMenuItems.size(); i++)
		{
			if (menu.menuItem_launcher.allMenuItems.get(i).getMeal().equals("Breakfast"))
	        {
	        	breakfastMenuItems.add(menu.menuItem_launcher.allMenuItems.get(i));
	        }
	        else if(menu.menuItem_launcher.allMenuItems.get(i).getMeal().equals("Lunch"))
	        {
	        	lunchMenuItems.add(menu.menuItem_launcher.allMenuItems.get(i));
	        }
	        else if (menu.menuItem_launcher.allMenuItems.get(i).getMeal().equals("Dinner"))
	        {
	        	dinnerMenuItems.add(menu.menuItem_launcher.allMenuItems.get(i));
	        }
		}
		
		//creating the 4 basic menus
		//All contains all menu items and by default is active
		menu.menus all = new menu.menus("All", menu.menuItem_launcher.allMenuItems, true);
		
		//bfast contains all breakfast menu items and by default is active
		menu.menus bfast = new menu.menus("Breakfast", breakfastMenuItems, true);
		
		//lunch contains all lunch menu items and by default is active
		menu.menus lunch = new menu.menus("Lunch", lunchMenuItems, true);
		
		//dinner contains all dinner menu items and by default is active
		menu.menus dinner = new menu.menus("Dinner", dinnerMenuItems, true);
		
		//adding all the created menus to the all menus list
		allMenus.add(all);
		allMenus.add(bfast);
		allMenus.add(lunch);
		allMenus.add(dinner);

	}
	
	//create menu function
	//creates a new menu based on the provided name, items, and activity
	//then adds it to the all menus list
	public static void createMenu(String name, List<menuItems> items, boolean active)
	{
		allMenus.add(new menus(name, items, active));
	}
	
	//get menu function
	//takes in a string name for a menu and returns the menu object
	public static menus getMenu(String n)
	{
		menus menu = new menus("", new ArrayList<menuItems>(),true);
		for (int i = 0; i<allMenus.size();i++)
		{
			if(allMenus.get(i).getMenuName().equals(n))
			{
				menu = allMenus.get(i);
			}
		}
		return menu;
	}
	
	//get menu index function
	//takes in a menu name and returns the index of where it is in the all menu list
	public static int getMenuIndex(String n)
	{
		int index=-1;
		for (int i =0; i< allMenus.size();i++)
		{
			if(allMenus.get(i).getMenuName().equals(n))
			{
				index=i;
			}
		}
		return index;
	}

}