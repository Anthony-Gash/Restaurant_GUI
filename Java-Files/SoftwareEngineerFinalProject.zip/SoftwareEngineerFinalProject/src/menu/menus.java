package menu;

import java.util.List;

//the menus class
public class menus
{
	//basic information for each menu
	String mName;
	List <menuItems> mItems;
	boolean mActive;

	//menu constructor
	public menus(String mN, List<menuItems> mI, boolean mA)
	{
		mName = mN;
		mItems = mI;
		mActive = mA;
	}
	
	//get menu name function, returns menu name
	public String getMenuName()
	{
		return mName;
	}
	
	//get menu items function, returns menu items
	public List <menuItems> getMenuItems()
	{
		return mItems;
	}
	
	//get menu activity function, returns menu activity
	public boolean getMenuActivity()
	{
		return mActive;
	}
	
	//set menu name function, takes in a new menu name and sets the menu name to that
	public void setMenuName(String mN)
	{
		mName= mN;
	}
	
	//set menu items function, takes in a new menu items and sets the menu items to that
	public void setMenuItems(List <menuItems> mI)
	{
		mItems = mI;
	}
	
	//set menu activity function, takes in a new menu activity and sets the menu activity to that
	public void setMenuActivity(boolean mA)
	{
		mActive = mA;
	}
}