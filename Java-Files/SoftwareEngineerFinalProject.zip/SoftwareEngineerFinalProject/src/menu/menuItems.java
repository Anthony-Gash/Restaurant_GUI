package menu;
//The menu item class
public class menuItems
{
	//basic information for each menu item
	String item;
	String price;
	String category;
	String description;
	String meal;
	
	//menu item constructor
	public menuItems(String i, String p, String c, String d, String m)
    {
		item = i;
		price = p;
		category = c;
		description = d;
		meal = m;
    }
	
	/**
	 * Copy constructor for menuItems.
	 * @param other - a menuItems object to copy data from.
	 */
	public menuItems(menuItems other) {
		this.item = other.getItem();
		this.price = other.getPrice();
		this.category = other.getCategory();
		this.description = other.getDescription();
		this.meal = other.getMeal();
	}
	
	//get item  function, returns item name
	public String getItem()
	{
		return item;
	}
	
	//get price function, returns the price
	public String getPrice()
	{
		return price;
	}
	
	//get category function, returns the category
	public String getCategory()
	{
		return category;
	}
	
	//get description function, returns the description
	public String getDescription()
	{
		return description;
	}
	
	//get meal function, returns the meal
	public String getMeal()
	{
		return meal;
	}
	
	//set item function, takes in a new item and sets the item to that
	public void setItem(String i)
	{
		item = i;
	}
	
	//set price function, takes in a new price and sets the price to that
	public void setPrice(String p)
	{
		price = p;
	}
	
	//set category function, takes in a category and sets the category to that
	public void setCategory(String c)
	{
		category = c;
	}
	
	//set description function, takes in a new description and sets the description to that
	public void setDescription(String d)
	{
		description = d;
	}
	
	//set meal function, takes in a new meal and sets the meal to that
	public void setMeal(String m)
	{
		meal = m;
	}
	
	//to string function that allows all the meal information to be outputed
	public String toString()
	{
		return String.format("%s %s %s %s %s", item, description, price, category, meal);
	}
	
	
}