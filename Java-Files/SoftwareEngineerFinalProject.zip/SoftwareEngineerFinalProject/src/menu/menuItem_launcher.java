package menu;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//menu item launcher class
public class menuItem_launcher
{
	//creates a menu with all items
	public static List<menuItems> allMenuItems = new ArrayList<menuItems> ();

	
	//populate menu functions
	//meant to populate the allMenuItems list from the values found in the csv
	public static void populateMenu()
	{
		//setting the csv to a string variable
		//THIS MUST BE CHANGED WHEN MOVING FILES TO A NEW COMPUTER
		//String csvFile = "/Users/macuser/eclipse-workspace/restaurantManagementSystem/menu/Restaurant Menu (B,L,D).csv";
		String csvFile = "/Users/anthonygash/Desktop/Restaurant Menu (B,L,D)2.0.csv";
		
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) 
        {
        	br.readLine();
            String line;
            
            //reading in the csv file
            //every item is by default added to the all menu items list
            //but based on their defined meal, added to one of the other 3 lists
            while ((line = br.readLine()) != null) 
            {            	
                String[] data = line.split(",");
                
                allMenuItems.add(new menuItems(data[0],data[1],data[2],data[3],data[4]));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	//get all items function
	//a way to access all menu items from other classes
	//returns all the menu items
	public static List<menuItems> getAllItems()
	{
		return allMenuItems;
	}
	
	//create item function
	//takes in all needed parameters and creates a new item
	//then it adds it to the all items list
	//then it adds it to the desired menu
	public static void createItem(String n, String p, String c, String d, String m)
	{
		//creates a new item with the provided details
		menu.menuItems newItem = new menu.menuItems(n, p, c, d, m);
		//adds the item to the all items list
		allMenuItems.add(newItem);
		//adds the item to the desired menu
		menu.menus_launcher.getMenu(m).getMenuItems().add(newItem);
	}
	
	//get item function
	//a way to get the menuItem when only the string name is provided
	//returns the menuItem object of the provided string
	public static menuItems getItem(String n)
	{
		menuItems temp =null;
		for (int i=0; i<allMenuItems.size();i++)
		{
			if (allMenuItems.get(i).getItem().equals(n))
			{
				temp = allMenuItems.get(i);
			}
		}
		return temp;
	}
	
}