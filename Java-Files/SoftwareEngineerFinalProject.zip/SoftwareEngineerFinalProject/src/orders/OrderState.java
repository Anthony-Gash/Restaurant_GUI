package orders;

/**
 * This enumeration defines states which
 * are used to signify the current point
 * of an order in its life cycle.
 * 
 * Values are described below:
 * 
 * CANCELLED - for cancelled orders
 * NEW - for newly created orders
 * COOKING_IN_PROGRESS - for orders being prepared
 * READY_FOR_CUSTOMER - ready to be taken to table
 * DELIVERED_TO_TABLE - has been given to customer
 * PAID_FOR - customer has paid bill
 * 
 * @author Luke Hoffman (gmaj9)
 * 
 */

//Define the OrderState enumeration values.
public enum OrderState {

	/**
	 * Important - all states should be listed chronologically so state incrementing can
	 * be implemented (it might be useful in the update order functionality to advance
	 * an order's state with a single button/checkmark/toggle/etc.).
	 */
	CANCELLED,
	NEW,
	COOKING_IN_PROGRESS,
	READY_FOR_CUSTOMER,
	DELIVERED_TO_TABLE,
	PAID_FOR
}
