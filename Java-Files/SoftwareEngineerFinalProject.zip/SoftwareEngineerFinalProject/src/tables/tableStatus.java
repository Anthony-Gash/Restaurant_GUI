package tables;

//Enum to represent the status of a table
public enum tableStatus {
 AVAILABLE,
 OCCUPIED,
 NEEDS_CLEANING
}