package tables;

import java.util.ArrayList;
import java.util.List;

public class Tables {
    private List<Table> tables;

    public Tables() {
        this.tables = new ArrayList<>();
        initializeTables();
    }
    
    /**
	 * Copy constructor for Tables outer class.
	 * @param other - A Tables object to copy data from.
	 */
	public Tables(Tables other) {
		// Set up an ArrayList for tables.
		this.tables = new ArrayList<>();
	
		// Add copies of other's tables to this object's ArrayList.
		for (int i = 0; i < other.tables.size(); i++) {
			this.tables.add(new Table(other.tables.get(i)));
		}
	}

    private void initializeTables() {
        tables.add(new Table(1, 6));
        tables.add(new Table(2, 2));
        tables.add(new Table(3, 4));
        tables.add(new Table(4, 4));
        tables.add(new Table(5, 4));
        tables.add(new Table(6, 4));
        tables.add(new Table(7, 4));
        tables.add(new Table(8, 2));
        tables.add(new Table(9, 2));
        tables.add(new Table(10, 2));
        tables.add(new Table(11, 2));
        tables.add(new Table(12, 2));
        tables.add(new Table(13, 2));
        tables.add(new Table(14, 3));
        tables.add(new Table(15, 3));
        tables.add(new Table(16, 3));
        tables.add(new Table(17, 3));
        tables.add(new Table(18, 3));
    }

    public void displayTables() {
        System.out.println("Table Number\tSeating Capacity\t\tStatus");
        for (Table table : tables) {
            System.out.println(table.getTableNumber() + "\t\t\t" + table.getSeatingCapacity() + "\t\t\t" + table.getStatus());
        }
    }

    public void changeTableStatus(int tableNumber, tableStatus newStatus) {
        for (Table table : tables) {
            if (table.getTableNumber() == tableNumber) {
                table.setStatus(newStatus);
                System.out.println("\nTable " + tableNumber + " status changed to " + newStatus);
                return;
            }
        }
        System.out.println("Table with number " + tableNumber + " not found.");
    }

    public void cycleTableStatus(int tableNumber) {
        for (Table table : tables) {
            if (table.getTableNumber() == tableNumber) {
                table.cycleStatus(); // This will call cycleStatus() on the individual table
                return;
            }
        }
        System.out.println("Table with number " + tableNumber + " not found.");
    }

    public List<Table> getTables() {
        return tables;
    }

    public static void main(String[] args) {
        Tables tables = new Tables();

        tables.displayTables();

        tables.changeTableStatus(2, tableStatus.OCCUPIED);

        tables.displayTables();
    }
}
