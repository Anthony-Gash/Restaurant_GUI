package tables;

/**
 * Class representing a table in the restaurant
 */
public class Table {
	private int tableNumber; // Table number
	private int seatingCapacity; // Seating capacity
	private tableStatus status; // Status of table

	/**
	 * Constructor for Table inner class.
	 * 
	 * @param tableNumber - An integer denoting the table number
	 * @param seatingCapacity - An integer denoting the table's maximum occcupants.
	 */
	public Table(int tableNumber, int seatingCapacity) {
		this.tableNumber = tableNumber;
		this.seatingCapacity = seatingCapacity;
		this.status = tableStatus.AVAILABLE; // Default status is available
	}

	/**
	 * Copy constructor for the Tables inner class.
	 * 
	 * @param other - A Table object to copy values from.
	 */
	public Table(Table other) {
		this.tableNumber = other.getTableNumber();
		this.seatingCapacity = other.getSeatingCapacity();
		this.status = other.getStatus();
	}

	/**
	 * Gets the table number.
	 * @return an integer representing the table number.
	 */
	public int getTableNumber() {
		return tableNumber;
	}
	/**
	 * Gets the table's seating capacity.
	 * @return an integere representing the table's seating capacity.
	 */
	public int getSeatingCapacity() {
		return seatingCapacity;
	}

	/**
	 * Gets the table's status.
	 * @return a tableStatus enum value representing the table's current status.
	 */
	public tableStatus getStatus() {
		return status;
	}

	/**
	 * Sets the table's status.
	 * @param status - a tableStatus enum value representing the new status to set.
	 */
	public void setStatus(tableStatus status) {
		this.status = status;
	}

	/**
	 * Method to cycle logically through a table's status. 
	 */
	public void cycleStatus() {
		switch (status) {
		case AVAILABLE:
			status = tableStatus.OCCUPIED;
			break;
		case OCCUPIED:
			status = tableStatus.NEEDS_CLEANING;
			break;
		case NEEDS_CLEANING:
			status = tableStatus.AVAILABLE;
			break;
			// Add more cases if needed
		}
	}
	
	@Override
	public String toString() {
		return "\t\t\t\t" + tableNumber + "\t\t\t\t" + status;
	}
}