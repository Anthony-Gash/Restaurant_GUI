package reservations;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReservationsManager {

    private static ReservationsManager instance = null;
    private List<Reservations> reservationsList = new ArrayList<>();

    // Private constructor to enforce singleton pattern
    private ReservationsManager() {}

    // Method to get the single instance of ReservationsManager
    public static ReservationsManager getInstance() {
        if (instance == null) {
            instance = new ReservationsManager();
        }
        return instance;
    }

    // Method to add a reservation to the list
    public void addReservation(Reservations reservation) {
        reservationsList.add(reservation);
    }

    // Method to fetch reservations for a specific date
    public List<Reservations> getReservationsForDate(LocalDate date) {
        List<Reservations> reservationsForDate = new ArrayList<>();
        for (Reservations reservation : reservationsList) {
            if (reservation.getDate().equals(date)) {
                reservationsForDate.add(reservation);
            }
        }
        return reservationsForDate;
    }

    // Method to get all reservations managed by ReservationsManager
    public List<Reservations> getAllReservations() {
        return new ArrayList<>(reservationsList);  // Return a copy of the list
    }
}
