package reservations;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Reservations {
    private int id;
    private String name; // Name for the reservation
    private LocalDate date; // Date of the reservation
	private String amPm; //AM or PM for the time
	private int hour;
	private String minute;
    private static int reservationCounter = 1;

    // Method to create a new reservation with a unique name
    public static Reservations createReservation(String name, LocalDate date, int hour, String minute, String amPm) {
        return new Reservations(name, date, hour, minute, amPm);
    }

    // Default constructor
    public Reservations(String name, LocalDate date, int hour, String minute, String amPm) {
        this.id = reservationCounter++;
        this.name = name;
        this.date = date;
        this.hour = hour;
        this.minute = minute;
        this.amPm = amPm;
    }



    // Getters and setters for the variables
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
    
    // Setter method for hour
    public void setHour(int hour) {
        this.hour = hour;
    }

    // Getter method for hour
    public int getHour() {
        return hour;
    }

    // Setter method for minute
    public void setMinute(String minute) {
        this.minute = minute;
    }

    // Getter method for minute
    public String getMinute() {
        return minute;
    }
    
    public void setAmPm(String amPm) {
        this.amPm = amPm;
    }

    public String getAmPm() {
        return amPm;
    }
    
    // Method to fetch reservations based on a specific date
    public static List<Reservations> fetchReservationsByDate(LocalDate date, List<Reservations> reservations) {
        List<Reservations> reservationsForDate = new ArrayList<>();

        for (Reservations reservation : reservations) {
            if (reservation.getDate().equals(date)) {
                reservationsForDate.add(reservation);
            }
        }

        return reservationsForDate;
    }


    
    // toString function to print out contents of the reservation
    @Override
    public String toString() {
        return "Reservation ID #" + id + "\n" + name + "\n" + 
        		hour + ":" + minute + " " + amPm + "\n";
    }

    public static void main(String[] args) {
        // Create an ArrayList to store Reservation objects
        ArrayList<Reservations> reservations = new ArrayList<>();

        // Add reservations to the ArrayList
        reservations.add(Reservations.createReservation("Gordon", LocalDate.of(2024, 3, 28), 7, "00", "PM"));
        reservations.add(Reservations.createReservation("Smith", LocalDate.of(2024, 3, 29), 10, "30", "AM"));
        reservations.add(Reservations.createReservation("Johnson", LocalDate.of(2024, 3, 30), 5, "15", "PM"));

        // Display the reservations
        for (Reservations reservation : reservations) {
            System.out.println(reservation);
        }

        // Remove a reservation by ID
        int idToRemove = 1; // Replace with the ID of the reservation you want to remove
        boolean removed = removeReservationById(reservations, idToRemove);
        if (removed) {
            System.out.println("Reservation with ID " + idToRemove + " removed successfully.");
        } else {
            System.out.println("No reservation found with ID " + idToRemove + ".");
        }
    }

    // Method to remove a reservation by ID
    public static boolean removeReservationById(ArrayList<Reservations> reservations, int id) {
        // Iterate over the reservations list
        for (int i = 0; i < reservations.size(); i++) {
            Reservations reservation = reservations.get(i);
            if (reservation.getId() == id) {
                // Remove the reservation and return true indicating successful removal
                reservations.remove(i);
                return true;
            }
        }
        // Return false if no reservation with the specified ID was found
        return false;
    }
}
